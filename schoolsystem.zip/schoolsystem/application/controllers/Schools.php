<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Schools extends CI_Controller {
	 public function __construct() {
		parent::__construct();
		$this->load->helper('url');
		// Load form helper library
		$this->load->helper('post');
		$this->load->library('encryption');	
		$this->load->library('pagination');	
	}
	public function index(){
		$data = array();
		if($this->session->userdata('user_email') != '')
		{
			redirect('/schools/allschool');
		}else{
			$this->load->view('/auth/login',$data,false);
		}
	}
	public function allschool($rowno=0,$sortBy="id",$order="asc"){
		$search = [];
		$search = $this->input->post(); 
		// Row per page
		$rowperpage = 20;
		// Row position 
		if($rowno != 0){ 
		   $rowno = ($rowno-1) * $rowperpage; 
		}
		// Set session
		if($this->uri->segment('4') != NULL ){
		  $this->session->set_userdata(array("sortBy"=>$sortBy));
		  $this->session->set_userdata(array("order"=>$order));
		}else{
		  if($this->session->userdata('sortBy') != NULL){
			$sortBy = $this->session->userdata('sortBy');
			$order = $this->session->userdata('order');
		  }
		}
		$objPost = new Post();
		// Total records count
		$allcount = $objPost->getrecordCount($this->session->userdata('user_id'),$search);
	
		// Get records
		$posts_record = $objPost->getData($this->session->userdata('user_id'),$rowno,$rowperpage,$sortBy,$order,$search);
		// Pagination Configuration
		$config['base_url'] = base_url().'index.php/schools/allschool';
		$config['use_page_numbers'] = TRUE;
		$config['total_rows'] = $allcount;
		$config['per_page'] = $rowperpage;
		// Initialize
		$this->pagination->initialize($config);
	
		$data['pagination'] = $this->pagination->create_links();
		$data['schools'] = $posts_record;
		$data['row'] = $rowno;
		$data['order'] = $order;
		// Load view
		$this->school_view('/school/allschool',$data);	
	}
	
	public function create()
	{	
		$data = [];
		$data['userId'] = $this->session->userdata('user_id');
		if(isset($_POST['name'])){
			$objPost = new Post();
			$objPost->saveSchoolInData($_POST);
			redirect('/schools/allschool');
		}else{			
			$this->school_view('/school/create',$data);
		}
	}
	
	public function saveEditBlog(){
		$objPost = new Post();
		$objPost->editBolgInData($this->input->post());
	}
	public function edit($schoolId = ''){
		$objPost = new Post();	
		$data['userId'] = $this->session->userdata('user_id');
		if(isset($_POST['name'])){
			$objPost->editSchoolInData($this->input->post());
			redirect('/schools/allschool');
		}else{
			$data['schoolData'] = $objPost->getSchoolById($schoolId);
			$this->school_view('/school/edit',$data);
		}		
	}
	public function delete($schoolId){
		$objPost = new Post();
		$result = $objPost->softDelete($schoolId);
		if( $result ){
			redirect('/schools/allschool');			
		}
	}
	function school_view($view, $data=array()){		
		$dat['dview'] = $data;
		$this->load->view('required/header', $data);		  		
		$this->load->view($view);
		$this->load->view('required/footer');
	}	
}
