<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {
	 public function __construct() {
		parent::__construct();
		/* load helpers */
		$this->load->helper(array('user_list'));        
	}
	public function index()
	{	
		$data = array();
		if($this->session->userdata('user_email') != '')
		{	
			
		}else{
			$this->load->view('/auth/login',$data,false);
		}		
	}
	public function register()
	{	
		$data = [];
		if(isset($_POST['email'])){
			$objUser = new User_list();
			$data['user'] = $objUser->saveUserInData($_POST);
			$this->load->view('/auth/login',$data,false);
		}else{
			$this->load->view('users/register',$data);
		}
	}
}
