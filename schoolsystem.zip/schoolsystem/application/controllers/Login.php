<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	public function __construct(){
		parent::__construct();
		/* load helpers */
		$this->load->helper(array('url','user_list'));
        
        /*load our user model that contains user authentication/insertion/updation functions*/
		$this->load->model('User','',true);
	}
	public function index(){
		$data		=		array();
		if( $this->is_user_logged_in() != false ){
			/* Authenticating the user session */	
			$user = $this->User->get_user_by_email($_REQUEST['email']);
		
			/* Creating user object */
			$userObject	= new User_list();
			/* Setting user session */
			$userObject->setLoginSession($user);
			/* remove used variables */
			unset($userObject);
			redirect(base_url('Schools'));
		}else{
			if(empty($_REQUEST)){
				$data['error_message'] = '';
				$this->load->view('/auth/login',$data,false);
			}else{
				if(isset($_REQUEST['event'])){
					$data['error_message'] = 'Please do proper login';
				}elseif(isset($_REQUEST['success_message'])){
					$data['error_message'] = '';	
				}else{
					$data['error_message'] = 'Invalid email or password';
				}
				$this->load->view('/auth/login',$data,false);
			}
		}		
	}
	
	public function is_user_logged_in(){
		$email = isset($_REQUEST['email'])?$_REQUEST['email']:'';
		$userPassword = isset($_REQUEST['password'])?($_REQUEST['password']):'';
		
		if( $email == '' && $userPassword == '')
			return false;

		//encrypt the password
		$password = md5( $userPassword );	
		$result = $this->db->get_where('user', array('email' => $email, 'password'=>$password,'deleted'=>0), 1, 0);
	  
		if( $result->num_rows() > 0 ){
			return $result->row_array();
		}
	  
		else
			return false;
	}
	
	/**
	 ** controller for logout
	 **/
	public function logout(){
		/* Unset the current session data */
		$this->session->unset_userdata('user_id');
		$this->session->unset_userdata('user_email');
		redirect('/login?success_message=You are logged out');
	}
}
