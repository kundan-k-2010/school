<?php
/**********************************************************************************/
/*Purpose 		: Adding/editing/deleting Process
/*Created By 	: Kundan Kumar
----------------------------------------------------------------------------------
Revision History :
----------------------------------------------------------------------------------
Updated By					Date of Upload			Comments
----------------------------------------------------------------------------------
Kundan Kumar					06-11-2016 				Created
/**********************************************************************************/




class User extends CI_Model {

   function __construct(){
       parent::__construct();
   }
    /**
    ** add_new_user
    ** @param array $user_array an array containing user information
    **/
    function add_new_user( $user_array = array() ){
      
      //check if the required fields are set
      if( !isset($user_array['email']) || !isset($user_array['password'])) 
      return false;
   
      $data = $user_array;
      
      //encrypt the password
      $data['password'] = md5( $user_array['password'] );
      
      $data['record_date'] = date('YmdHis');
      if( $this->db->insert('user', $data) )
      return $this->db->insert_id();
      else
      return false;      
   }
   /**
    ** get user details using his email
    ** @param string $email email to search for
    ** @return db object on success else boolean false
    **/
    function get_user_by_email( $email='' ) {
      
      if( $email == '' )
      return false;
	  
      $result = $this->db->get_where('user', array('email' => $email, 'deleted'=>0), 1, 0);
	  
	  if( $result->num_rows() > 0 ) {
        return $result->row_array();
      }	  
      else
      return false;
      
	}
} 