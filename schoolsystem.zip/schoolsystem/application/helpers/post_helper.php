<?php
class Post {
	public function __construct(){        
        $this->ci = &get_instance();
		$this->ci->load->model('Common','',true);
		/* Load the encryption library  */
		$this->ci->load->library('encryption');		
    }
	public function getData($userId='',$rowno,$rowperpage,$sortBy,$order,$search)
	{
		$searchCondition = '';
		if(!empty($search['name'])){
			$searchCondition = "school.name like '%".$search['name']."%' AND";
		}
		$schoolData = $this->ci->Common->bind_query('SELECT school.id,school.name,school.location,school.record_date,user.first_name,user.last_name FROM school INNER JOIN user ON school.user_id=user.id WHERE '.$searchCondition.' user.id = '.$userId.' AND school.deleted = 0 AND user.deleted = 0 ORDER BY school.'.$sortBy.' '.$order.' LIMIT '.$rowno.','.$rowperpage);
		return $schoolData;
	}
	public function getrecordCount($userId='',$search)
	{
		$searchCondition = '';
		if(!empty($search['name'])){
			$searchCondition = "school.name like '%".$search['name']."%' AND";
		}
		$schoolDataCount = $this->ci->Common->bind_query('SELECT COUNT(school.id) as countData FROM school INNER JOIN user ON school.user_id=user.id WHERE '.$searchCondition.' school.deleted = 0 AND user.deleted = 0 ORDER BY school.id DESC');	
		return $schoolDataCount[0]->countData;
	}
	public function getSchoolById($schoolId = '')
	{
		$schoolData = $this->ci->Common->bind_query('SELECT school.id,school.name,school.location,school.record_date,school.user_id FROM school INNER JOIN user ON school.user_id=user.id WHERE  school.id = '.$schoolId.' AND school.deleted = 0 AND user.deleted = 0 ORDER BY school.id DESC');
		return $schoolData;
	}	
	public function saveSchoolInData($schoolDetails = array())
	{
		$data = array(
			'name'=>$schoolDetails['name'],
			'location'=>$schoolDetails['location'],
			'user_id'=>$schoolDetails['user_id'],
			'record_date' => date('Ymdhis')
		);
		$schoolId = $this->ci->Common->insert_data('school',$data);					
	}
	public function editSchoolInData($schoolDetails = array())
	{	
		$data = array(
			'user_id'=>$schoolDetails['user_id'],
			'name'=>$schoolDetails['name'],
			'location'=>$schoolDetails['location'],
			'updated_date' => date('Ymdhis')
		);
		$schoolId = $this->ci->Common->update_data('school',$data,$schoolDetails['school_id']);				
	}
	public function softDelete($schoolId = ''){
		$data = array(
			'deleted'=>'1',
			'updated_date' => date('Ymdhis')
		);
		$schId = $this->ci->Common->soft_delete('school',$data,$schoolId);
		return $schId;	
	}
}
