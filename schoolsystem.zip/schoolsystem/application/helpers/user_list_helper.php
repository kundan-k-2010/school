<?php
/**********************************************************************************/
/*Purpose 		: Getting the user and personel details.
/*Created By 	: Kundan Kumar.
----------------------------------------------------------------------------------
Revision History :
----------------------------------------------------------------------------------
Updated By					Date of Upload			Comments
----------------------------------------------------------------------------------
Kundan Kumar				06-11-2022 				Created
/**********************************************************************************/
class User_list {    
    /**
     ** This is defined as ci instance in controller
     ** Used for quering database
     **/
    private $ci;
	private $_userArr		= array();
	private $_locationArr	= array();
	private $_roleArr		= array();
	
	public function __construct($pLocationArr = array(), $pRoleArr	= array()){ 
		date_default_timezone_set("Asia/Calcutta");
        $this->ci = &get_instance();
		//load our Common model 
		$this->ci->load->model('Common','',true);		
		$this->ci->load->model('User','',true);
		$this->_userArr	 = array();	
    }
	/******************************************************************************************/
	/*Purpose	: Setting current active login user session.
	/*Inputs	: $user	:: contains login user session,				
	/*Returns	: On Web service request return value else not.
	/*Created By: Kundan Kumar.
	/******************************************************************************************/
	public function setLoginSession($user = ''){
		/* if user is found then do then needful */
		if(isset($user) && ($user != '')){
			$this->ci->session->set_userdata(array(
                            'user_id'  		=> $user['id'],
                            'user_email'    => $user['email']                           
                    ));
		}			
	}
	public function saveUserInData($userDetails = array())
	{		
		$userData = array( 
			'first_name' => strip_tags($userDetails['first_name']), 
			'last_name' => strip_tags($userDetails['last_name']), 
			'email' => strip_tags($userDetails['email']), 
			'password' => md5(strip_tags($userDetails['password'])),
			'record_date'    => date('YmdHis')
		); 
		$userId = $this->ci->Common->insert_data('user',$userData);	
		return 	$userId;	
	}
}