<!--DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: black;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: white;
  width: 40%;
  margin-left: 33%;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>

<form method="post">
  <div class="container">
  <label><a href="<?php echo base_url();?>login">Login</a></label>
    <h1>User Register</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>
    <label for="first_name"><b>First Name</b></label>
    <input type="text" placeholder="Enter First Name" name="first_name" required>
    <label for="last_name"><b>Last Name</b></label>
    <input type="text" placeholder="Enter Last Name" name="last_name" required>
    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>
    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>
    <button type="submit" class="registerbtn">Register</button>
  </div>
</form>
</body>
</html-->
<DOCTYPE html>
<html lang="en-US">
    <head>
       <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="<?php echo base_url();?>skin/css/bootstrap.min.css" type="text/css">
      <link rel="stylesheet" href="<?php echo base_url();?>skin/css/font-awesome.min.css" type="text/css">
      <link rel="stylesheet" href="<?php echo base_url();?>skin/css/AdminLTE.min.css" type="text/css">
      <link rel="stylesheet" href="<?php echo base_url();?>skin/css/open-sans.css" type="text/css">
      <link rel="stylesheet" href="<?php echo base_url();?>skin/css/skin-blue.min.css" type="text/css">
      <link rel="stylesheet" href="<?php echo base_url();?>skin/css/chosen.min.css" type="text/css">
      <link rel="stylesheet" href="<?php echo base_url();?>skin/css/custom.css" type="text/css">
      <link rel="stylesheet" href="<?php echo base_url();?>skin/css/jquery.datetimepicker.css" type="text/css">
      <link rel="stylesheet" href="<?php echo base_url();?>skin/css/daterangepicker.css" type="text/css">
      <link rel="stylesheet" href="<?php echo base_url();?>skin/css/jquery.mCustomScrollbar.css" type="text/css">
      <title>School System</title>
    </head>
	<body class="login_bg">
		<div class="container" id="loginForm">
			<div class="row">
				<div class="col-sm-6 col-md-4 col-md-offset-4">
					<div class="panel panel-default">
						<div class="panel-heading">
							<strong> Registration</strong>
						</div>
						<div class="panel-body">
            <form method="post">
								<fieldset>
									<div class="row">
										<div class="col-sm-12 col-md-10  col-md-offset-1 ">
                      <div class="form-group">
												<div class="input-group">
													<span class="input-group-addon">
													<span class="user-icon">&nbsp;</span>
													</span> 
													<input class="form-control first_name" placeholder="Enter First Name" name="first_name" id="first_name" type="text" required>
												</div>
											</div>
                      <div class="form-group">
												<div class="input-group">
													<span class="input-group-addon">
													<span class="user-icon">&nbsp;</span>
													</span> 
													<input class="form-control last_name" placeholder="Enter Last Name" name="last_name" id="last_name" type="text" required>
												</div>
											</div>
                      <div class="form-group">
												<div class="input-group">
													<span class="input-group-addon">
													<span class="user-icon">&nbsp;</span>
													</span> 
													<input type="text" class="form-control email" placeholder="Email" name="email" id="email" autofocus required>
												</div>
											</div>
                      <div class="form-group">
												<div class="input-group">
													<span class="input-group-addon">
													<span class="user-pass-icon">&nbsp;</span>
													</span> 
													<input type="password" class="form-control password" placeholder="Password" name="password" id="password" required>
												</div>
											</div>
											<div class="form-group">
												<input type="submit" class="btn btn-lg btn-primary btn-block" value="Register" name="" id="" >
											</div>
										</div>
									</div>
								</fieldset>
							</form>
							<form>
								<fieldset>
									<div class="form-group">
										<label><a href="<?php echo base_url();?>login" class="btn btn-lg btn-primary btn-block" style="width: 330px;">Login</a></label>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>