<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo isset($metadata['page_title']) && $metadata['page_title'] != '' ? $metadata['page_title'] : 'School system';  ?> </title>
	 <base href="<?php echo base_url(); ?>">
    <link rel="canonical" href="<?php echo base_url(); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0, minimum-scale=1, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="" />     
    <link rel="stylesheet" type="text/css" href="template/css/form.css"/>
    <meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/bootstrap.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/font-awesome.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/AdminLTE.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/open-sans.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/skin-blue.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/chosen.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/custom.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/jquery.datetimepicker.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/daterangepicker.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/jquery.mCustomScrollbar.css" type="text/css">
		<title>School System</title>	
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>skin/images/favicon.ico">
</head>
<body class="">
	<header class="TunesHeader">
        <div class="container"></div>
	</header>    
<div class="bodywrap">
  <div class="container">
  <label><a href="<?php echo base_url(); ?>Schools">Home</a></label>
  <label><a href="<?php echo base_url(); ?>login/logout">Logout</a></label>