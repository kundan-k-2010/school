        <div class="clear">&nbsp;</div>
    </div> 
  </div>
    <footer>
        <div class="container"> </div>
    </footer>
	<script type='text/javascript' src='template/js/jquery-1.11.3.min.js'></script>	
	<script src="template/js/script.js"></script>
</body>
</html>