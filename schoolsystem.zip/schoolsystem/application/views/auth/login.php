<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/bootstrap.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/font-awesome.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/AdminLTE.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/open-sans.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/skin-blue.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/chosen.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/custom.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/jquery.datetimepicker.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/daterangepicker.css" type="text/css">
		<link rel="stylesheet" href="<?php echo base_url();?>skin/css/jquery.mCustomScrollbar.css" type="text/css">
		<title>School System</title>
	</head>
	<body class="login_bg">
		<div class="container" id="loginForm">
			<div class="row">
				<div class="col-sm-6 col-md-4 col-md-offset-4">
					<div class="panel panel-default">
						<div class="panel-heading">
							<strong> Sign in to continue</strong>
						</div>
						<div class="panel-body">
							<form name="userLoginForm" id="userLoginForm" class="userLoginForm" action="<?php echo base_url();?>login/">
								<fieldset>
									<div class="row">
										<div class="col-sm-12 col-md-10  col-md-offset-1 ">
											<div class="form-group">
												<div class="input-group">
													<span class="input-group-addon">
													<span class="user-icon">&nbsp;</span>
													</span> 
													<input class="form-control email" placeholder="Email" name="email" id="email" type="text" autofocus>
												</div>
											</div>
											<div class="form-group">
												<div class="input-group">
													<span class="input-group-addon">
													<span class="user-pass-icon">&nbsp;</span>
													</span>
													<input class="form-control password" placeholder="Password" name="password" id="password" type="password" value="">
												</div>
											</div>
											<div class="form-group">
												<input type="submit" class="btn btn-lg btn-primary btn-block loginSubmit" value="Login" name="loginSubmit" id="loginSubmit" >
											</div>
										</div>
									</div>
								</fieldset>
							</form>
							<form>
								<fieldset>
									<div class="form-group">
										<label><a href="<?php echo base_url(); ?>Users/register" class="btn btn-lg btn-primary btn-block" style="width: 330px;">Register</a></label>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>