<div class="container-fluid white-bg">
<?php if(isset($page_title)){?>
<div class="pt10 pb20">
<div style="height:500px;" class="section"> 		
<table width="100%" class="data-table">
	<td width="70%">
		<h2 class="primary-heading">ToolTip Attributes</h2>
	</td>
</table>

<table width="100%" class="data-table div-widget-arrtibute-align-panel-action-object">	
	<td width="30%">
		<?php if(isset($layout_option)){?>
			<select name="cboWidgetDropDown" id="cboWidgetDropDown" class="input-select"><?php echo $layout_option?></select>				
		<?php }?>
		<input type="hidden" name="txtModuleTopCode" id="txtModuleTopCode" value="<?php echo $module_code?>" />
	</td>
	<td>
		<input type="button" name="button" id="button" value="Add" class="pos-act-mid-btn update_close" onClick="addWidgetAttribute1('div-widget-arrtibute-align-panel');">
	</td>
</table>
<table width="100%" class="div-widget-arrtibute-align-panel-container">
	<td width="70%" ref='1' class="widget-seection-title"></td>
</table>
<div class="div-widget-arrtibute-align-panel-action">
		<div class="div-widget-arrtibute-align-panel"><?php echo $att_list; ?></div>
	</div>
<?php $intSectionCount = 1; include_once('tooltip-template-form.php');?>	
</div>
</div>
<?php }?>

</div>
<div id="div-overlay-success" class="data-wrap success-message none"></div>
<div class="container-fluid white-bg">
<div class="div-template-container" ></div>
</div>
