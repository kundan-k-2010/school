<div class="div-msg">
	<?php if(isset($_REQUEST['success_message'])){?>
		<div class="">
	<?php }?>
</div>
<form name="frmSearch" id="frmSearch" name="frmSearch" method="post"></form>
<div class="data-wrap">
	<?php echo $table?>
	<?php print_r($pagination); ?>
</div>
