<div class='align-right pb10'>
	<form name="frmWidgetAttribute" id="frmWidgetAttribute" method="post" action="<?php echo SITE_URL?>settings/widget/layout_tooltip_attribute/?template=save">
		<?php for($intCounterForLoop = 1; $intCounterForLoop <= $intSectionCount; $intCounterForLoop++){?>
			<input type="hidden" name="txtSection[]" id="txtSection<?php echo $intCounterForLoop?>" value="<?php if(isset($result[$intCounterForLoop])){ echo implode(A_DELIMITER,$result[$intCounterForLoop]);}?>" />
		<?php }?>
		<input type="hidden" name="txt" id="txtSection1" value="" />
		<input type="hidden" name="txtModuleCode" id="txtModuleCode" value="" />
		<input type="hidden" name="txtLayoutCode" id="txtLayoutCode" value="" />
		<span class="valid-error">No Attribute added in any section.</span>
		<input type="button" name="cmdSaveWidgetAttribute" id="cmdSaveWidgetAttribute" onClick="saveWidgetAttributes();" value="Submit" class="pos-act-mid-btn update_close mr10" />		
		<a href="javascript:void(0);" onClick="closeOverlay();" class="primary-link fb-close">Cancel</a>		
	</form>
</div>

<?php 
if($intSectionCount == 1){
	echo '<script language="Javascript">setPreSelectTemplateAttributes(\'div-widget-arrtibute-align-panel\');</script>';
}else{
	echo '<script language="Javascript">';
	for($intCounterForLoop = 1; $intCounterForLoop <= $intSectionCount; $intCounterForLoop++){
		echo "setPreSelectTemplateAttributes('div-widget-arrtibute-align-".$intCounterForLoop."-panel');";
	}
	echo '</script>';
}
?>


