<div class="container-fluid white-bg">
<?php if(isset($page_title)){?>
<div class="pt10 pb20">
<table width="100%">
	<td width="70%">
		<h2 class="primary-heading"><?php echo $page_title;?></h2>
	</td>
	<td width="30%">
		<?php if(isset($layout_option)){?>
			<select name="cboLayoutList" id="cboLayoutList" class="input-select"><?php echo $layout_option?></select>				
		<?php }?>
		<input type="hidden" name="txtModuleTopCode" id="txtModuleTopCode" value="<?php echo $module_code?>" />
	</td>
</table>
</div>
<?php }?>
</div>
<div id="div-overlay-success" class="data-wrap success-message none"></div>
<div class="container-fluid white-bg">
<div class="div-template-container" ></div>
</div>

