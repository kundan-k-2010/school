<div style="height:500px">
	<div class="row">
		<?php for($intCounterLoop = 1; $intCounterLoop <=6; $intCounterLoop++){?>
			<div class="col-md-6 section">	
				<div class="section-heading brd-b-none">
					<table width="100%" class="div-widget-arrtibute-align-panel-container div-widget-arrtibute-align-<?php echo $intCounterLoop?>-panel-container">
						<td width="70%" ref='<?php echo $intCounterLoop?>' class="widget-seection-title">Section <?php echo $intCounterLoop?></td>
						<td width="30%" class="widget-seection-aligment">
							<select name="cboLayoutDisplayStyle" id="cboLayoutDisplayStyle" class="input-select" onChange="setTheWidgetLayoutAppreance('div-widget-arrtibute-align-<?php echo $intCounterLoop?>-panel');">
								<option value="">Select View Style</option>
								<option value="2">Row</option>
								<option value="1" selected>Column</option>
							</select>
						</td>
					</table>
				</div>
				<div class="div-widget-arrtibute-align-<?php echo $intCounterLoop?>-panel div-widget-arrtibute-align-panel"></div>	
				<table class="data-table div-widget-arrtibute-align-<?php echo $intCounterLoop?>-panel-action div-widget-arrtibute-align-<?php echo $intCounterLoop?>-panel-action-object">
					<td width="30%">
						<select class="input-select" name="cboWidgetDropDown" id="cboWidgetDropDown"><?php echo $att_list?></select>
					</td>
					<td width="70%">
						<input type="button" name="button" id="button" value="Add" class="pos-act-mid-btn update_close" onClick="addWidgetAttribute('div-widget-arrtibute-align-<?php echo $intCounterLoop?>-panel');">
						<span class="valid-error column_row"></span>
					</td>
				</table>	
			</div>
		<?php }?>
	</div>
</div>
<?php $intSectionCount = 6; include_once('template-form.php');?>