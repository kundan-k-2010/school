<?php 
/**********************************************************************************/
/*Purpose 		: Manage the Dashboard View.
/*Created By 	: Jaiswar Vipin Kumar R.
----------------------------------------------------------------------------------
Revision History :
----------------------------------------------------------------------------------
Updated By					Date of Upload			Comments
----------------------------------------------------------------------------------
Jaiswar Vipin Kumar R.		17-05-2016 				Updated FOS location loading alignment.
Jaiswar Vipin Kumar R.		23-05-2016 				Updated FOS location, Funnel, Data chart and TAT get displayed to the RSM only.
/**********************************************************************************/
?>
<div class="page-heading">
	<div class="fl"><h2>Welcome <?php echo $user_first_name; ?></h2></div>
	<div class="fr">
		<!--input type="button" value="+ Add New Lead" class="add-lead-btn"--> 
		<a href="<?php echo base_url(); ?>lead-management/leads/add" class="add-lead-btn">Add New Lead</a>
		<input name='cboGlobalCompany' id='cboGlobalCompany' class='input-select none' value="<?php echo $companyCode;?>" />			
	</div>
	<div class="clear dashboard-identifire"></div>
</div>
<div class="spacer-15">
	<?php if(isRSMRole($role_code)){ ?>
		<div class="row">
			<div class="col-md-12">
				<div class="section-heading brd-b-none mt20">
					<form name="frmFunnal" id="frmFunnal" method="post" action="">
						<table width="100%" class="">
							<tr>
								<td width="55%">Lead Conversion - Funnel Visualisation</td>
								<td width="35"><label class="font-12">From</label></td>
								<td width="80">
									<input type="text" value="<?php echo $from_widget_date ?>" class="date-only input-text" id="txtFunnalFromDate" name="txtFunnalFromDate" />
									<span class="valid-error">Invalid From Date</span>
								</td>
								<td width="45"><span class="cal-icon date-only-label" ref="txtFunnalFromDate">Calendar</span></td>
								<td width="18"><label class="font-12">To</label></td>
								<td width="80">
									<input type="text" value="<?php echo $yesterday_date?>" class="date-only input-text" id="txtFunnalToDate" name="txtFunnalToDate">
									<span class="valid-error">Invalid From Date</span>
								</td>
								<td width="45"><span class="cal-icon date-only-label" ref="txtFunnalToDate">Calendar</span></td>
								<td><input type="button" value="Submit" class="blue-dark-btn btn-dashboard-lead-funnal" /></td>
							</tr>
						</table>
					</form>
				</div>
				<div class="div-lead-by-business-division div-lead-by-funnal mCustomScrollbar"><?php echo $funnal?> </div>
			</div>
		</div>
	
		<div class="row">
			<div class="col-md-12">
				<div class="section-heading brd-b-none mt20">
					<form name="frmLeadConversion" id="frmLeadConversion" method="post" action="">
						<table width="100%" class="">
							<tr>
								<td width="95%">FOS location report</td>						
								<td width="5%"><span class="filter-icon fr"></span></td>
							</tr>
						</table>
					</form>
				</div>
				<div class="data-map">
					<div class="location-icon">
						<script type="text/javascript" src="http://code.jquery.com/jquery-2.1.0.min.js"></script>
						<!--script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script -->
						<script type="text/javascript" src="http://maps.google.com/maps/api/js"></script>
						<script type="text/javascript" src="<?php echo base_url().'skin/js/admin_map.js'?>"></script></script>
						<script type="text/javascript" src="<?php echo base_url().'skin/js/map.js'?>"></script></script>
						
						<div id="divAgentLocation" style="width: 100%; height: 450px;">
							<div style="position:absolute;left:50%;top:50%;width:100%;height:100%;opacity:0.5;font-size:30px;">Loading....</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12">
				<div class="section-heading brd-b-none mt20">
					<form name="frmLeadSourceWiseCount" id="frmLeadSourceWiseCount" method="post" action="">
						<table width="100%" class="">
							<tr>
								<td width="58%">Lead Source Wise Details</td>
								<td width="14%">
									<table>
										<tr>
											<td><input type="checkbox" value="1" name="chkIncludeDuplicate" id="chkIncludeDuplicate"  checked ="checked" />&nbsp;<label class="font-12">Include Duplicate Leads</label></td>
										</tr>
									</table>
								</td>
								<td width="12%">
									<table>
										<tr>
											<td width="35"><label class="font-12">From</label></td>
											<td width="80">
												<input type="text" value="<?php echo $from_widget_date?>" class="date-only input-text" id="txtLeadStatusWiseFromDate" name="txtLeadStatusWiseFromDate" />
												<span class="valid-error">Invalid From Date</span>
											</td>
											<td width="45"><span class="cal-icon date-only-label" ref="txtLeadStatusWiseFromDate">Calendar</span></td>
										</tr>
									</table>
								</td>
								<td width="10%">
									<table>
										<tr>
											<td width="18"><label class="font-12">To</label></td>
											<td width="80">
												<input type="text" value="<?php echo $yesterday_date?>" class="date-only input-text" id="txtLeadStatusWiseToDate" name="txtLeadStatusWiseToDate">
												<span class="valid-error">Invalid From Date</span>
											</td>
											<td width="45"><span class="cal-icon date-only-label" ref="txtLeadStatusWiseToDate">Calendar</span></td>
										</tr>
									</table>
								</td>
								<td width="6%"><input type="button" value="Submit" class="blue-dark-btn mr10" onClick="showDashboradWidgetData('divLeadStatusWiseCount','lead-by-status','txtLeadStatusWiseFromDate','txtLeadStatusWiseToDate');" /></td>	
							</tr>
						</table>
					</form>
				</div>
				<div class="div-lead" id="divLeadStatusWiseCount"><?php echo $leads;?></div>
			</div>	
		</div>
		
		<div class="row">
			<div class="col-md-12">
				<div class="section-heading brd-b-none mt20">
					<form name="frmLeadRegionWiseCount" id="frmLeadRegionWiseCount" method="post" action="">
						<table width="100%" class="">
							<tr>
								<td width="58%">Lead Region Wise Details</td>
								<td width="14%">
									<table>
										<tr>
											<td><input type="checkbox" value="1" name="chkIncludeRegionDuplicate" id="chkIncludeRegionDuplicate"  checked ="checked" />&nbsp;<label class="font-12">Include Duplicate Leads</label></td>
										</tr>
									</table>
								</td>
								<td width="12%">
									<table>
										<tr>
											<td width="35"><label class="font-12">From</label></td>
											<td width="80">
												<input type="text" value="<?php echo $from_widget_date?>" class="date-only input-text" id="txtLeadRegionWiseFromDate" name="txtLeadRegionWiseFromDate" />
												<span class="valid-error">Invalid From Date</span>
											</td>
											<td width="45"><span class="cal-icon date-only-label" ref="txtLeadRegionWiseFromDate">Calendar</span></td>
										</tr>
									</table>
								</td>
								<td width="10%">
									<table>
										<tr>
											<td width="18"><label class="font-12">To</label></td>
											<td width="80">
												<input type="text" value="<?php echo $yesterday_date?>" class="date-only input-text" id="txtLeadRegionWiseToDate" name="txtLeadRegionWiseToDate">
												<span class="valid-error">Invalid From Date</span>
											</td>
											<td width="45"><span class="cal-icon date-only-label" ref="txtLeadRegionWiseToDate">Calendar</span></td>
										</tr>
									</table>
								</td>
								<td width="6%"><input type="button" value="Submit" class="blue-dark-btn mr10" onClick="showDashboradWidgetData('divLeadRegionWiseCount','lead-by-region','txtLeadRegionWiseFromDate','txtLeadRegionWiseToDate');" /></td>	
							</tr>
						</table>
					</form>
				</div>
				<div class="div-lead" id="divLeadRegionWiseCount"><?php echo $region_leads;?></div>
			</div>	
		</div>
	
		<div class="row">
			<div class="col-md-12">
			<form name="frmTatDateRange" id="frmTatDateRange" method="post" action="">
				<div class="section-heading brd-b-none mt20">
					
						<table width="100%" class="">
							<tr>
								<td width="900">My Turn Around Time (TAT)</td>
								<td width="35"><label class="font-12">From</label></td>
								<td width="80">
									<input type="text" value="<?php echo $from_widget_date ; ?>" class="date-only input-text" id="txtTatFromDate" name="txtTatFromDate" />
									<span class="valid-error">Invalid From Date</span>
								</td>
								<td width="45"><span class="cal-icon date-only-label" ref="txtTatFromDate">Calendar</span></td>
								<td width="18"><label class="font-12">To</label></td>
								<td width="80">
									<input type="text" value="<?php echo $yesterday_date; ?>" class="date-only input-text" id="txtTatToDate" name="txtTatToDate">
									<span class="valid-error">Invalid From Date</span>
								</td>
								<td width="45"><span class="cal-icon date-only-label" ref="txtTatToDate">Calendar</span></td>
								<td width="35"><label class="font-12">Executive</label></td>
								<td width="210">
									<select name="cboExecutive" id="cboExecutive" class="input-select">
										<option value="">Select</option>
										<?php echo $repoteValue; ?>
									</select>
								</td>
								<td><input type="button" value="Submit" class="blue-dark-btn mr10 btn-dashboard-tat" /></td>
							</tr>
						</table>
					
				</div>
				<div class="div-tat-report" ><?php echo $tat_report; ?></div>
				</form>
			</div>
		</div>
	
	<?php } ?>
	
	<div class="row">
	
	<?php if(in_array($role_as , array(R_LEAD_RA,R_LEAD_RM,R_LEAD_RA_ONLY_TELE_ASSIGN,R_LEAD_RA_ONLY_FOS_ASSIGN,R_LEAD_RA_NO_ASSIGMENT, R_LEAD_RA_ONLY_FOS_ASSIGN_WITHOUT_REPORTEE, R_LEAD_RA_ONLY_TELE_ASSIGN_WITHOUT_REPORTEE,R_FOS)) ) { ?>
	
		<form name="frmJumpToLead" id="frmJumpToLead" method="post" action="" class="none"><input type="hidden" name="txtInternalCode" id="txtInternalCode" value="" /></form>
		
			<div class="col-md-6">
				<div class="section-heading mt20 brd-b-none">New Leads</div>
				<table class="data-table" id="tblNewLeads">
					<tr>
						<?php $all_leads = ''; 
							if(!empty($columns)){
							foreach($columns[1] as $columnsKey => $columnsValue){
								echo '<th>'.$columnsValue['title'].'</th>';
							}
						}?>
					</tr>
					<?php
					$intCounterForLoop = 1;
					if(!empty($columns)){						
						foreach( $new_leads_array as $new_lead){
							$intCounterForLoop++;
							echo '<tr id="'.$encryption->encode($new_lead->lead_code).'">';
							foreach($columns[1] as $columnsKey => $columnsValue){
								if($columnsValue['type'] == 'dropdown'){
									if($columnsValue['id'] == 'country'){
										$strValue	= isset($country[$new_lead->$columnsValue['id']])?$country[$new_lead->$columnsValue['id']]['label']:'-';
									}else{
										$strValue	= isset($search[$columnsValue['id']][$new_lead->$columnsValue['id']])?$search[$columnsValue['id']][$new_lead->$columnsValue['id']]['label']:'-';
									}
									
									echo '<td>'.$strValue.'</td>';
								}else{
									echo '<td>'.$new_lead->$columnsValue['id'].'</td>';									
								}
							}
							echo '</tr>';
							$status = $new_lead->status;
						}
					}
					
					for($intCounter = $intCounterForLoop; $intCounter <= 5; $intCounter++){
						echo '<tr>';
						echo '<td>&nbsp;-</td>';
						echo '<td>&nbsp;-</td>';
						echo '<td>&nbsp;-</td>';
						echo '<td>&nbsp;-</td>';
						echo '</tr>';						
					}
					
					?>			
				</table>
				<?php //debugVar($total_new_leads);
				if(!empty($new_leads_array)){ ?>
					<!--div class="fr mt10">
						<div><a id="newLeadsDashboardLink" href="<?php echo base_url(); ?>lead-management/all_leads?status=<?php echo $encryption->encode($status); ?>">
						<?php
							foreach($total_new_leads as $total_new_leadsVal){
								echo "All(".$total_new_leadsVal->totalNewLeads.")"; 
							}		
						?>
						</a></div>
					</div-->
				<?php 	} ?>
			</div>
			<div class="col-md-6">
				<div class="section-heading mt20 brd-b-none">
					<form name="frmTopTaskPending" id="frmTopTaskPending" method="post" action="">
						<table width="100%" class="">
							<tbody>
								<tr>
									<td width="220">Top Task Pending</td>
									<td align="right">
										<table class="date_table_right">
											<tr>
												<td><label class="font-12">From</label></td>
												
												<td>
													<input type="text" value="<?php echo $from_widget_date;?>" class="date-only input-text date_input_box" id="txtTopTaskPendingFromDate" name="txtTopTaskPendingFromDate" />
												</td>
												
												<td class="cal_icon_td">
													<span class="cal-icon date-only-label" ref="txtTopTaskPendingFromDate">Calendar</span>
												</td>
												
												<td><label class="font-12">To</label></td>
												
												<td>
													<input type="text" value="<?php echo $yesterday_date; ?>" class="date-only input-text date_input_box" id="txtTopTaskPendingToDate" name="txtTopTaskPendingToDate" />
												</td>
												<td class="cal_icon_td">
													<span class="cal-icon date-only-label" ref="txtTopTaskPendingToDate">Calendar</span>
												</td>
												
												<td>
													<input type="button" value="Submit" class="blue-dark-btn" onClick="showDashboradWidgetData('tblTopTaskPending','top_pending_task','txtTopTaskPendingFromDate','txtTopTaskPendingToDate');">
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</form>
				</div>
				<div id='tblTopTaskPending'>
					<table class="data-table" id="">
						<tr>
							<?php 
								echo '<th>Employee Name</th>';						
								echo '<th>Manager Name</th>';						
								echo '<th>Task</th>';
								echo '<th>Count</th>';
							?>
						</tr>
						<?php 
							$intCounterForLoop = 1;
							foreach( $top_pending_task as $top_pending_taskKey => $top_pending_taskVal){
								$intCounterForLoop++;
								echo '<tr>';
								echo '<td>'.$top_pending_taskVal->leadOwnerName.'</td>';
								echo '<td>'.$top_pending_taskVal->managername.'</td>';
								echo '<td>'.$top_pending_taskVal->tasktype.'</td>';
								echo '<td>'.$top_pending_taskVal->task.'</td>';
								echo '</tr>';
							}
							
							for($intCounter = $intCounterForLoop; $intCounter <=5; $intCounter++){
								echo '<tr >';
								echo '<td>&nbsp;-</td>';				
								echo '<td>&nbsp;-</td>';				
								echo '<td>&nbsp;-</td>';
								echo '<td>&nbsp;-</td>';
								echo '</tr>';
							}
						?>
					</table>
				</div>
			</div>
		<?php } ?>
	<?php if(in_array($role_as , array(R_ADMIN,R_LEAD_RM,R_LEAD_RA,R_LEAD_RA_ONLY_TELE_ASSIGN,R_LEAD_RA_ONLY_FOS_ASSIGN))){ ?>
		<?php if(!isTeleCallerAndFosAssigmentRole($user_role)){?>
			<div class="col-md-6">
				<div class="section-heading mt20 brd-b-none">
					<form name="frmTopPerformance" id="frmTopPerformance" method="post" action="">
						<table width="100%" class="">
							<tbody>
								<tr>
									<td width="220">Top Performers</td>
									<td width="35"><label class="font-12">From</label></td>
									<td width="80">
										<input type="text" value="<?php echo $from_widget_date;?>" class="date-only input-text" id="txtTopPerformanceFromDate" name="txtTopPerformanceFromDate" />
									</td>
									<td width="45"><span class="cal-icon date-only-label" ref="txtTopPerformanceFromDate">Calendar</span></td>
									<td width="18"><label class="font-12">To</label></td>
									<td width="80">
										<input type="text" value="<?php echo $yesterday_date; ?>" class="date-only input-text" id="txtTopPerformanceToDate" name="txtTopPerformanceToDate" />
									</td>
									<td width="45"><span class="cal-icon date-only-label" ref="txtTopPerformanceToDate">Calendar</span></td>
									<td><input type="button" value="Submit" class="blue-dark-btn mr10" onClick="showDashboradWidgetData('tblTopPerformance','top_performance','txtTopPerformanceFromDate','txtTopPerformanceToDate');"></td>
								</tr>
							</tbody>
						</table>
					</form>
				</div>
				<div id="datatable1" class="topPerformance" style="display:none;"></div>
				<div id="tblTopPerformance">
					<table class="data-table" id="">
						<tr>
							<?php //echo "<pre>"; print_r($top_performance);
							$allEmployeePerformance = '';

							echo '<th>Employee Name</th>';						
							echo '<th>Team</th>'; 
							echo '<th>Team Leader</th>'; 						
							echo '<th>Lead Assigned</th>';
							echo '<th>Success</th>';
							echo '<th>%</th>';
							?>
						</tr>
						<?php 
							$top_performance['user_code'] = array();
							$intCurrentUSerCode	= $top_performance['user_code'];
							unset($top_performance['user_code']);
							$blnIsUserInTop5 	= false;
							$intCounterForLoop = 1;
							
							foreach( $top_performance as $empPerformanceKey=>$empPerformance){
								if($intCounterForLoop <= 5){
									if($intCurrentUSerCode == $empPerformanceKey){
										$blnIsUserInTop5 	= true;									
									}
									$intCounterForLoop++;
									
									echo '<tr >';
									echo '<td>'.$empPerformance['employeename'].'</td>';				
									/* if($role_as == ASM){  */
										echo '<td>'.$empPerformance['location'].'</td>';	
										echo '<td>'.$empPerformance['manageruser'].'</td>';	
									/* }			 */
									echo '<td>'.$empPerformance['leadCount'].'</td>';
									echo '<td>'.(($empPerformance['kyc']!='')?$empPerformance['kyc']:'-').'</td>';
									echo '<td>'.(($empPerformance['percentage']!='')?$empPerformance['percentage']:'-').'</td>';								
									echo '</tr>';
								}
							}
							
							for($intCounter = $intCounterForLoop; $intCounter <=5; $intCounter++){
								echo '<tr >';
								echo '<td>&nbsp;-</td>';												
								echo '<td>&nbsp;-</td>';				
								echo '<td>&nbsp;-</td>';									
								echo '<td>&nbsp;-</td>';				
								echo '<td>&nbsp;-</td>';				
								echo '<td>&nbsp;-</td>';				
								echo '</tr>';
							}
						
						?>
					</table>
				</div>
				<!--div class="fr mt10">
					<div><a ><?php if(!empty($top_performance)) { 
					echo "All(".count($top_performance).")"; } ?></a></div>
				</div-->
			</div>
		
			<div class="col-md-6">
				<div class="section-heading mt20 brd-b-none">
					<form name="frmEmployeePerformance" id="frmEmployeePerformance" method="post" action="">
						<table width="100%" class="">
							<tbody>
								<tr>
									<td width="220">Team Performers</td>
									<td width="35"><label class="font-12">From</label></td>
									<td width="80">
										<input type="text" value="<?php echo $from_widget_date;?>" class="date-only input-text" id="txtEmployeePerformanceFromDate" name="txtEmployeePerformanceFromDate" />
									</td>
									<td width="45"><span class="cal-icon date-only-label" ref="txtEmployeePerformanceFromDate">Calendar</span></td>
									<td width="18"><label class="font-12">To</label></td>
									<td width="80">
										<input type="text" value="<?php echo $yesterday_date; ?>" class="date-only input-text" id="txtEmployeePerformanceToDate" name="txtEmployeePerformanceToDate" />
									</td>
									<td width="45"><span class="cal-icon date-only-label" ref="txtEmployeePerformanceToDate">Calendar</span></td>
									<td><input type="button" value="Submit" class="blue-dark-btn mr10" onClick="showDashboradWidgetData('tblTopEmployeePerformance','employee_performance','txtEmployeePerformanceFromDate','txtEmployeePerformanceToDate');"></td>
								</tr>
							</tbody>
						</table>
					</form>
				</div>
				<div id="datatable1" class="myPerformance" style="display:none;"></div>
				<div id="tblTopEmployeePerformance">
					<table class="data-table" id="tblEmpPerformance">
						<tr>
							<?php 
							$allEmployeePerformance = '';
							echo '<th>Team Location</th>';
							echo '<th>Lead Assigned</th>';
							echo '<th>Success</th>';
							echo '<th>%</th>';
							?>
						</tr>
						<?php 
							$employee_performance['user_code'] = array();
							$intCurrentUSerCode	= $employee_performance['user_code'];
							//unset($employee_performance['user_code']);
							$blnIsUserInTop5 	= false;
							$intCounterForLoop = 1;
							
							foreach( $employee_performance as $empPerformanceKey=>$empPerformance){						
								if($empPerformanceKey == 'user_code'){
									continue;
								}
								if($intCounterForLoop <= 5){
									if($intCurrentUSerCode == $empPerformanceKey){
										$blnIsUserInTop5 	= true;
									}
									
									echo '<tr >';
									echo '<td>'.$empPerformance['location'].'</td>';
									echo '<td>'.$empPerformance['leadCount'].'</td>';
									echo '<td>'.(($empPerformance['kyc']!='')?$empPerformance['kyc']:'-').'</td>';
									echo '<td>'.(($empPerformance['percentage']!='')?$empPerformance['percentage']:'-').'</td>';								
									echo '</tr>';
									
									
								}
								
								$intCounterForLoop++;
							}
							
							for($intCounter = $intCounterForLoop; $intCounter <=5; $intCounter++){
								echo '<tr >';
								echo '<td>&nbsp;-</td>';				
								echo '<td>&nbsp;-</td>';
								echo '<td>&nbsp;-</td>';
								echo '<td>&nbsp;-</td>';
								echo '</tr>';
							}
						
						?>
					</table>
				</div>
				<!--div class="fr mt10">
					<div><a id="" ><?php if(!empty($employee_performance)) { 
					echo "All(".count($employee_performance).")"; } ?></a></div>
				</div-->
			</div>		
		<?php } ?>
	<?php } ?>
	
	<?php if(in_array($role_as , array(R_LEAD_RA_ONLY_TELE_ASSIGN, R_LEAD_RA_NO_ASSIGMENT))){ ?>	
		<div class="col-md-6">
			<div class="section-heading mt20 brd-b-none">My Team Tasks</div>
			<table class="data-table" id="tblLeadsPendingTask">
				<tr>
					<?php //echo "<pre>"; print_r($pending_tasks);
					if(!empty($columns)){
						echo '<th>Days</th>';
						echo '<th>Task</th>';
						
					}?>
				</tr>
				<?php if(!empty($columns)){
					
					foreach( $pending_tasks as $pendingTasksKey=>$pendingTasksVal){
						
						echo '<tr style="background-color:'.$pendingTasksVal[3].'">';
						echo '<td>'.$pendingTasksKey.'</td>';
						echo '<td><a href="'.base_url().'lead-management/tasks?toDate='.$encryption->encode($pendingTasksVal[1]).'&fromDate='.$encryption->encode($pendingTasksVal[2]).'">'.$pendingTasksVal[0].'</a></td>';
						echo '</tr>';
					}
				}?>
				
			</table>
			<!--div class="fr mt10">
				<div><a href="<?php echo base_url(); ?>lead-management/tasks"><?php if(!empty($total_pending_tasks)) { 
				echo "All(".$total_pending_tasks.")"; } ?></a></div>
			</div-->
			
		</div>
		
	<?php } ?>
		<div class="col-md-6">
			<div class="section-heading mt20 brd-b-none">
				<form name="frmEmployeePerformance" id="frmEmployeePerformance" method="post" action="">
					<table width="100%" class="">
						<tbody>
							<tr>
								<td width="220">All Employee Performance</td>
								<td width="35"><label class="font-12">From</label></td>
								<td width="80">
									<input type="text" value="<?php echo $from_widget_date;?>" class="date-only input-text" id="txtAllEmployeePerformanceFromDate" name="txtAllEmployeePerformanceFromDate" />
								</td>
								<td width="45"><span class="cal-icon date-only-label" ref="txtAllEmployeePerformanceFromDate">Calendar</span></td>
								<td width="18"><label class="font-12">To</label></td>
								<td width="80">
									<input type="text" value="<?php echo $yesterday_date; ?>" class="date-only input-text" id="txtAllEmployeePerformanceToDate" name="txtAllEmployeePerformanceToDate" />
								</td>
								<td width="45"><span class="cal-icon date-only-label" ref="txtAllEmployeePerformanceToDate">Calendar</span></td>
								<td><input type="button" value="Submit" class="blue-dark-btn mr10" onClick="showDashboradWidgetData('tblAllEmployeePerformance','all_employee_performance','txtAllEmployeePerformanceFromDate','txtAllEmployeePerformanceToDate');"></td>
							</tr>
						</tbody>
					</table>
				</form>
			</div>
			<div id="datatable1" class="myPerformance" style="display:none;"></div>
			<div id="tblAllEmployeePerformance">
				<table class="data-table" id="tblEmpPerformance">
					<tr>
						<?php 
						$allEmployeePerformance = '';
						echo '<th>Employee Name</th>';
						echo '<th>Lead Assigned</th>';
						echo '<th>Success</th>';
						echo '<th>%</th>';
						?>
					</tr>
					<?php 
						if(!empty($all_employee_performance)){														
							$blnIsUserInTop5 	= false;
							$intCounterForLoop = 1;
							
							foreach( $all_employee_performance as $empPerformanceKey=>$empPerformance){						
								if($intCounterForLoop <= 5){
									if($intCurrentUSerCode == $empPerformanceKey){
										$blnIsUserInTop5 	= true;
									}
									
									echo '<tr >';
									echo '<td>'.$empPerformance['employeename'].'</td>';				
									echo '<td>'.$empPerformance['leadCount'].'</td>';
									echo '<td>'.(($empPerformance['kyc']!='')?$empPerformance['kyc']:'-').'</td>';
									echo '<td>'.(($empPerformance['percentage']!='')?$empPerformance['percentage']:'-').'</td>';								
									echo '</tr>';
								}
								$intCounterForLoop++;
							}
						}
						
						for($intCounter = $intCounterForLoop; $intCounter <=5; $intCounter++){
							echo '<tr >';
							echo '<td>&nbsp;-</td>';				
							echo '<td>&nbsp;-</td>';				
							echo '<td>&nbsp;-</td>';
							echo '<td>&nbsp;-</td>';								
							echo '</tr>';
						}
					?>
				</table>
				
				<!--div class="fr mt10">
					<div><a id="employeePerformanceDetails" ><?php if(!empty($employee_performance)) { 
					echo "All(".count($employee_performance).")"; } ?></a></div>
				</div-->
				<?php if((isset($blnIsUserInTop5)) && (!$blnIsUserInTop5)){?>
					<?php
						$strPosition	= '';
						if((!empty($employee_performance)) && (isset($employee_performance[$intCurrentUSerCode]))) { 
							$strPosition	=  "Your position : " .$employee_performance[$intCurrentUSerCode]['position']; 
							
						 ?>
							<div class="fl mt10">
								<!--div><?php echo $strPosition. "(".$employee_performance[$intCurrentUSerCode]['percentage']."% conversion ratio)"; ?></div-->
							</div>
				<?php } }?>
			</div>
		</div>
		
		<div class="col-md-6">
			<div class="row">
				<div class="col-md-12">
					<div class="section-heading brd-b-none mt20">
						<form name="frmMyPerformance" id="frmMyPerformance" method="post" action="">
							<table width="100%" class="">
								<tbody>
									<tr>
										<?php 
											$strPerformance	= 'My Performance';
											/* if($role == R_LEAD_RM){
												$strPerformance	= 'Executive Performance';
											} */
										?>
										<td width="220"><?php echo $strPerformance?></td>
										<td width="120"></td>
										<td width="20"></td>
										<td width="35"><label class="font-12">From</label></td>
										<td width="80">
											<input type="text" value="<?php echo $from_widget_date?>" class="date-only input-text" id="txtMyPerformanceFromDate" name="txtMyPerformanceFromDate" />
										</td>
										<td width="45"><span class="cal-icon date-only-label" ref="txtMyPerformanceFromDate">Calendar</span></td>
										<td width="18"><label class="font-12">To</label></td>
										<td width="80">
											<input type="text" value="<?php echo $yesterday_date?>" class="date-only input-text" id="txtMyPerformanceToDate" name="txtMyPerformanceToDate" />
										</td>
										<td width="45"><span class="cal-icon date-only-label" ref="txtMyPerformanceToDate">Calendar</span></td>
										<td><input type="button" value="Submit" class="blue-dark-btn mr10 btn-dashboard-my-performance-button"></td>
									</tr>
								</tbody>
							</table>
						</form>
					</div>
					<div id="div-employee" style="min-width: 310px; height: 300px; margin: 0 auto"></div>
					<table id="datatable" class="myPerformance" style="display:none;">					
						<thead>
							<tr>
								<th></th>
								<th>Conversion</th>
							</tr>
						</thead>
						<tbody>
							<?php 
							//echo "<pre>";	print_r($my_performance);	echo "<pre>";
							foreach($my_performance as $my_performanceKey => $my_performanceDetails){?>
								<tr>
									<th><?php echo format_date($my_performanceDetails->months,0)?></th>
									<td><?php echo $my_performanceDetails->leadCount?></td>								
								</tr>
							<?php }?>								
						</tbody>
					</table>
					<div class="font-9"><i><b>Note:</b> Data available till yesterdays date.</i></div>
				</div>
			</div>	
			<div class="row">
				<div class="col-md-12">
				</div>
			</div>
		</div>
	
	</div>
</div>