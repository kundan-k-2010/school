<?php
/**********************************************************************************/
/*Purpose 		: Creating the full page layout with all passed attributes.
/*Created By 	: Jaiswar Vipin Kumar R.
----------------------------------------------------------------------------------
Revision History :
----------------------------------------------------------------------------------
Updated By					Date of Upload			Comments
----------------------------------------------------------------------------------
Jaiswar Vipin Kumar R		06-01-2016 				Added the reports HTML.
/**********************************************************************************/
//print_r($leads); exit(0);
//print_r($table);
?>

<?php if(isset($page_title)){
	if($ajax_report_lead==''){?>
	<div class="page-heading">			
		<div class="fl"><h2><?php echo $page_title;?></h2></div>
		
		<?php if(isset($excelPath)){?>
			<div class="a-center" >Requested excel is created successfully. <a href="<?php echo SITE_URL.ADVERT_CSV_DOWNLOAD_PATH.$excelPath?>" target="_blank">click here</a> to download the file.</div>
		<?php }?>
		<?php //if(isset($excelDownload)){?>
			<!--div class="a-center" >Requested excel is created successfuly. <a href="<?php //echo SITE_URL.ADVERT_CSV_DOWNLOAD_PATH.$excelDownload?>" target="_blank">click here</a> to download the file.</div-->
		<?php //}?>
		
		<div class="fr">
		<?php if(($page_title <> 'Lead Reports') && ($page_title <> 'Task Reports')) { ?>
			<a href="<?php echo base_url(); ?>lead-management/leads/add" class="add-lead-btn">Add New Lead</a>
		<?php } ?>
			<?php if(isset($companyCode)){ echo getCompanyList($companyCode); };?>
			<input name='cboGlobalCompany' id='cboGlobalCompany' class='input-select none' value="<?php echo $companyCode;?>" />
			<?php if(!isset($hide_add_new) && (isset($add_item_title)) ){ ?>
				<a href="<?php echo base_url().$controller; ?>/add" class="bulk-action-btn dropdown add-new-job ajax-link">Add New <?php if(isset($add_item_title)){ echo $add_item_title ;};?></a>
			<?php } ?>
			
			<?php if(isset($bulk_action)){?>
				<div class="pos-relative inline-block">
					<a href="javascript:void(0);" class="bulk-action-btn dropdown">Bulk Action <span class="arrow-dw-white ml2"></span></a>
					<ul class="dropdown-list"><?php //if($role_as <> RA_FOS) {?>
						<?php if(($role == R_FOS) || ($role == R_LEAD_RA_NO_ASSIGMENT)) { ?>						
							<li><a href="javascript:void(0);" class="mail_open">Email</a></li> 
						<?php } else { ?>
							<?php if($page_title <> 'Tasks') { ?>
								<li><a href="javascript:void(0);" class="assign_open">Assign / Transfer</a></li> 
							<?php } ?>
							<!--li><a href="javascript:void(0);" class="update_open">Update</a></li-->
							<li><a href="javascript:void(0);" class="mail_open">Email</a></li> 
						<?php } ?>
						<!--<li><a href="javascript:void(0);" onclick = '$("#btncustomreport").click();'>Export to Excel</a></li>-->						
						<li><a href="javascript:void(0);" onclick = 'reportexceldownload();'>Export to Excel</a></li>						
						<?php if(isTeleCallerAndFosAssigmentRole($user_role)){?>
							<li><a href="javascript:void(0);" onclick = 'showMassLeadUploadDialog()'>Import Leads</a></li>
						<?php }?>
					</ul>
				</div>
			<?php }?>
			
			<?php if(isset($date_filter_action)){ ?>
				<div class="pos-relative block fr ml10">
					<form name="frmReports" id="frmReports" method="post" action="">
						<table class="date_table_right">
							<tr>
								<td><label class="font-12">From</label></td>
								<td>
									<input type="text" value="<?php echo $from_date; ?>" class="date-only input-text" id="txtLeadFromDate" name="txtLeadFromDate" />
									<span class="valid-error column_row">Invalid From Date</span>
								</td>
								<td class="cal_icon_td"><span class="cal-icon date-only-label" ref="txtLeadFromDate">Calendar</span></td>
								<td><label class="font-12">To</label></td>
								<td>
									<input type="text" value="<?php echo $to_date; ?>" class="date-only input-text" id="txtLeadToDate" name="txtLeadToDate">
									<span class="valid-error column_row">Invalid From Date</span>
								</td>
								
								<td class="cal_icon_td"><span class="cal-icon date-only-label" ref="txtLeadToDate">Calendar</span></td>
								<?php if($showFilter) { ?>
									<!--td width="45"><select name="cboCityList" id="cboCityList" style="float:right; height:23px;margin-right:10px;" class="input-select"></select></td-->
									<td width="131"><?php echo $cityDetaiilsList?></td>
								<?php }?>
								<td><input type="button" value="Submit" style="float:right" class="blue-dark-btn btn-reports-date_search" /></td>
								 
							</tr>
						</table>
						
					</form>
				</div>	
			<?php } ?>
			<?php if(isset($reports) || isset($taskreport) ){ ?>
				<div class="pos-relative block fr pt3">
					<select name="changeReports" onchange="changeReports(this.value)" id="changeReports" class="changeReports input-select" style="float:right; height:23px">
					<?php if(isset($reports)){ ?>
						<option value="reports" selected="selected">Lead</option>
						<option value="reports_task">Task</option>
					<?php } if(isset($taskreport)){ ?>
						<option value="reports">Lead</option>
						<option value="reports_task" selected="selected">Task</option>
					<?php } ?>	
					</select>
				</div>			
			<?php } ?>	
			<?php if(isset($excel_download)){?>
				<div class="pos-relative inline-block" style='display:none;'>
				    <input type='hidden' value='excel' name='hiddtextcustomreportdwntyp' id ='hiddtextcustomreportdwntyp'>
					<div class="align-right"><a href="#"><span onclick = 'reportexceldownload()' name='btncustomreport' id ='btncustomreport'><img src="<?php echo base_url() ?>skin/images/excel.png" width="19px;" height="18px;" align="bottom"></span></a></div>
				</div>
			<?php } ?>
			
		<div class="clear"></div>
	</div>
	<?php } ?>
	<div class="div-customer-profile"></div>
	<div class="div-msg">
		<?php if(isset($_REQUEST['success_message'])){?>
			<div class=""></div>
		<?php }?>
	</div>
	<?php if(isset($_REQUEST['txtInternalCode'])){?>
		<input type="hidden" name="txtProcessInternalCode" id="txtProcessInternalCode" value="<?php echo $_REQUEST['txtInternalCode']?>" />
	<?php }?>
	<form name="frmSearch" id="frmSearch" name="frmSearch" method="post"></form>
	<?php if(isset($reports)){ ?>
		<div class="">
	<?php } else{ ?>
		<div class="row">
	<?php }?>
	
	<?php $noBackGroundClass	= '';
	if(isset($reports)){
		$noBackGroundClass	= 'no-background';
		if($reports['lead_conversion']){?>
			<div class="col-md-12">
				<div class="section-heading mt15">
					<table width="100%" class="">
						<tr>
							<td>Lead Conversion</td>
						</tr>
					</table>
				</div>
				<?php 
					/* Checking is reports set or not */
					echo $reports['lead_conversion'];
				?>
			</div>
	<?php } if($reports['lead_status']){ ?>
		<div class="col-md-6">
			<div class="section-heading mt10">
				<table width="100%" class="">
					<tr>
						<td width="200">Lead Status Reports</td>
					</tr>
				</table>
			</div>
			<?php 
				/* Checking is reports set or not */
				echo $reports['lead_status'];
			?>
		</div>
	<?php } if($reports['lead_segment']){ ?>
		<div class="col-md-6">
			<div class="section-heading mt10">
				<table width="100%" class="">
					<tr>
						<td width="200">Lead Source Report</td>
					</tr>
				</table>
			</div>
			<?php 
				/* Checking is reports set or not */
				echo $reports['lead_segment'];
			?>
		</div>
		<?php } ?>		
	<?php } else{
		echo "</div>";
	}?>
		
	<div class="">
	<?php if(isset($taskreport)){
			$noBackGroundClass	= 'no-background';
			if($taskreport['my_task']){ ?>
		<div class="col-md-12">
			<div class="section-heading brd-b-none mt10">
				<table width="100%" class="">
					<tr>
						<td width="200">My Tasks</td>
					</tr>
				</table>
			</div>	
		
				<?php echo $taskreport['my_task']; ?>
		</div>		
			<?php } if($taskreport['task_status']){ ?>
		<div class="col-md-6">
			<div class="section-heading brd-b-none mt10">
				<table width="100%" class="">
					<tr>
						<td width="200">Task Status</td>
					</tr>
				</table>
			</div>	
				<?php echo $taskreport['task_status']; ?>
		</div>
				<?php } if($taskreport['task_type']){ ?>					
					<div class="col-md-6">
						<div class="section-heading brd-b-none mt10">
							<table width="100%" class="">
								<tr>
									<td width="200">Task Type</td>
								</tr>
							</table>
						</div>	
						<?php echo $taskreport['task_type']; ?>
					</div>
				<?php } ?>	
		<?php } else{
				echo "</div>";
			}?>	
		</div>
		<div class="data-wrap <?php echo $noBackGroundClass?>">
			<?php if(($page_title == 'Lead Reports')) { 
				if($ajax_report_lead==''){?>				
					
						<div class="spacer-5 column_row">
							<div class="section-heading mt10 brd-b-none">
								<table width="100%" class="">
									<th>
										<td>Leads</td>
										
										<td>
											<table class="date_table_right" id="data_table_reportscheckbox">
													<tr>
														<td>
															<input type="checkbox" name="isReenter" id="isReenter" class="isReenter" checked="checked">
														</td>
														
														<td class="font-12">
															[R] (Re-entry)
														</td>
														<td>
															<input type="checkbox" name="isduplicate" id="isduplicate" class="isduplicate"  checked="checked">
														</td>
														
														<td class="font-12">
															[D] (Duplicate)
														</td>
														<?php if(isset($excel_download_reports)){ ?>	
														<td>
															<input type='hidden' value='excel' name='hiddtextcustomreportdwntyp' id ='hiddtextcustomreportdwntyp'>
														</td>
														<td>
															<a href="JavaScript:void(0);" onclick = 'reportexceldownload();'><img src="<?php echo base_url() ?>skin/images/excel.png" width="19px;" height="18px;" align="bottom"></a>
														</td> 
														<?php } ?>	
													</tr>
												</table>
											</td>
										
									</th>
								</table>
							</div>
						</div>
					
					
			<?php 	}
				} 
			?>
			
			<?php if(($page_title == 'Task Reports')) { ?>				
				<div class="" id='div_report_task'>
					<div class="section-heading brd-b-none mt10">
						<table width="100%" class="">
							<th>
								<td width="200">Tasks</td>
								<td align="right" style="padding-left:200px;"><input type="checkbox" name="pending" id="pending" value="pending" align="right"/>&nbsp;Pending&nbsp;&nbsp;&nbsp;<input type="checkbox" name="completed" id="completed" value="completed" />&nbsp;Completed</td>
								<?php if(isset($excel_download_reports)){ ?>	
									<td>
										<input type='hidden' value='excel' name='hiddtextcustomreportdwntyp' id ='hiddtextcustomreportdwntyp'>
										<div class="align-right"><a href="#"><span onclick = 'reportexceldownload()' name='btncustomreport' id ='btncustomreport'><img src="<?php echo base_url() ?>skin/images/excel.png" width="19px;" height="18px;" align="bottom"></span></a></div>
									</td>
								<?php } ?>
							</th>					
						</table>
					</div>
				</div>
			<?php } ?>	
					<?php if($ajax_report_lead == ''){?>
						<div class="div-report-task-table div-all-lead-task-table">
					<?php }else{?>
						<div class="div-report-task-table-container">
					<?php }?>
						<?php echo $table?>
						<?php print_r($pagination); ?>
				</div>
			</div>
		</div>
	</div>	
</div>
<?php } else {
	echo $table;
 } ?>
