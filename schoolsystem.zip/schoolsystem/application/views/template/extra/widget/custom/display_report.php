<div class="div-report-task-table">
		<?php echo $table?>
		<?php print_r($pagination); ?>
		</div>