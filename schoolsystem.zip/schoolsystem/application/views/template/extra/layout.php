<?php 
/* Checking attributes is set */
$blbAttrSet	= isset($attrset)?$attrset:true;
/* Rendering header */
$this->view('template/header',array('attrset'=>$blbAttrSet));

if(isset($roles)){
	parent::get_my_role();
}
/* Renderting body */
if(isset($content)){
	echo $content;
}
/* rendering footer */
//$this->view('template/footer');
?>