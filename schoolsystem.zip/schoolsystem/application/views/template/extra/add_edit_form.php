<?php $page_title	= preg_replace("/\<.*\>/i",'',$page_title);?>
<div class="overly column_row" id="ajax-modal-content">
	<div class="overly-header"><?php echo $page_title; ?><span class="update_close overly-close-btn">Close</span></div>
	<div class="error-message"></div>
	<div class="spacer-15 div-action-panel column_row">
		<?php echo form_header(); ?>
		<!--Markup goes here-->
		<?php echo $form; ?>
		<!--#Markup goes here-->
	</div>				
</div>