<?php

echo '<h1>'.$singular_name.'</h1>';

?>
<style>
	table tr td:nth-child(4),
	table tr td:nth-child(5),
	table tr td:nth-child(6)
	{ 
		display: none;
	}

</style>

<div>
<h3 class="show_more_btn borderRadius_20 btn pull_right" id="showmore"> <a href='#'>Show more</a> </h3>

</div>

<table class='bankResolve' border='1' cellpadding='5' cellspacing='0' align='left'>
	<tr>
		<td>Id</td>
		<td>Description</td>
		<td>Parent id</td>
		<td>Car type</td>
		<td>Updated date</td>
		<td>Record date</td>
		<td>Deleted</td>
	</tr>
	
<?php foreach($all_items as $all_item) { ?>
	<tr>
		<td><?php echo $all_item->id; ?></td>
		<td><?php echo $all_item->description; ?></td>
		<td><?php echo $all_item->parent_id; ?></td>
		<td><?php echo $all_item->car_type; ?></td>
		<td><?php echo $all_item->updated_date; ?></td>
		<td><?php echo $all_item->record_date; ?></td>
		<td><?php echo $all_item->deleted; ?></td>
	</tr>
<?php } ?>

</table>
<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<script>
	$(document).ready(function () {  	  
		$('.bankResolve').slice(0, 2).show();
	
		$("#showmore").on('click', function (e) { 
			e.preventDefault();
			$('.bankResolve :hidden').slice(0, 2).slideDown();
			if ($('.bankResolve :hidden').length == 0) {
				$("#load").fadeOut('slow');
			}
			$('html,body').animate({
				scrollTop: $(this).offset().top
			}, 1500);
		});   
	
		$('.show_more_btn').click(function(){
			$('.full_width').addClass('show');			
			$('.full_width').removeClass('hide');
			$('.half_width').addClass('hide');			
		}); 
		
		$('.more_btn').click(function(){
			$('body').addClass('popup_show');			
		}); 
	   
		/* $('.popup_close').click(function(){
		  $('body').removeClass('popup_show');
		}); */
		
		/* $('#showmore').click(function () {
			$('#content_wrapper').css({
				'width': $('#content_wrapper').width() + 770.0
			});
			$('.main_wapper').niceScroll({cursorwidth:'12px', autohidemode:false, cursorborderradius:'4px', }); 
		});  */
		
		//$("html").niceScroll({cursorwidth:'12px', autohidemode:false, cursorborderradius:'4px', });
	
	
	});

</script>