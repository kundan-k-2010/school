<?php 

$this->view('template/header',array('header'=>false));

if(isset($content)){
	echo $content;
}
?>