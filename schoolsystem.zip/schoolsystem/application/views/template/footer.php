<footer class="main-footer"> 
    <!-- Default to the left -->
    copyright &copy; 2016 <a href="#">Z-Aksys Solutions Pvt. Ltd</a>. All rights reserved.
  </footer> 
</div>
<?php echo put_footers();?>
</body>
</html>
