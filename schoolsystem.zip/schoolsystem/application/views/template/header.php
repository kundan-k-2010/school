<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script>
			var base_url = "<?php echo base_url(); ?>";	
		</script>		 
		<title>Bank Resolve</title>
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>skin/images/favicon.ico">
		<?php echo put_headers(); ?>
	</head>
	<body class="skin-blue sidebar-mini">
		<div class="wrapper">
			<header class="main-header">
				<!-- Logo -->
				<a href="<?php echo base_url(); ?>car_trace" class="logo">
					<span class="logo-mini"><img src="<?php echo base_url(); ?>skin/images/logo-mini.png" /></span>
					<span class="logo-lg"><img src="<?php echo base_url(); ?>skin/images/logo.png" /><span class="logo_text">Bank Resolve</span></span>
				</a>
				<!-- Header Navbar -->
				<nav class="navbar navbar-static-top" role="navigation">   
					<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"> <span class="sr-only">Toggle navigation</span> </a>
					<div class="navbar-custom-menu">
						<ul class="nav navbar-nav br-admin-nav"> 						
							<li class="border-lr"><a href="<?php echo base_url(); ?>login/logout" class="">Sign out</a></li>
							<li>
								<a data-toggle="modal" href="#myModal" class="viewUserDetails" id="viewUserDetails" name="viewUserDetails" value="<?php echo $user_id; ?>">
									<img src="<?php echo base_url(); ?>skin/images/Profile-icon.png" class="user-image" alt="User Image" width="25px">
									<span class="hidden-xs"><?php echo $user_first_name; ?></span>
								</a>
							</li>						
						</ul>
					</div>
				</nav>
			</header>
			<!-- Left side column. contains the logo and sidebar -->
			<aside class="main-sidebar">
			<!-- sidebar: style can be found in sidebar.less -->
			<section class="sidebar br-sidebar">  
				<ul class="sidebar-menu">
				<?php 
					$car_traceActiveClass = $service_request_traceActiveClass = $loan_facility_traceActiveClass = $loan_consultation_traceActiveClass = $user_traceActiveClass = $hidLoanTypeCookie = $loanrestrtraceActiveClass = $settlementActiveClass = $loanconsoltraceActiveClass = $chatTraceActiveClass = $setting_traceActiveClass = $request_legal_consultation_traceActiveClass = $banktraceActiveClass = $bankadministrativeusertraceActiveClass = $agencytraceActiveClass = $collectionagencyadministrativeusertraceActiveClass = $car_listActiveClass = $imported_carsActiveClass = $imported_logsActiveClass = $maketraceActiveClass = $platecodetraceActiveClass = $unknowncartraceActiveClass = '';
					switch ($this->router->fetch_class()) {
						case 'car_trace':
							$car_traceActiveClass = 'class="active"';
							break;
						case 'car_list':
							$car_listActiveClass = 'class="active"';
							break;
						case 'imported_car':
							$imported_carsActiveClass = 'class="active"';
							break;
						case 'import_log':
							$imported_logsActiveClass = 'class="active"';
							break;
						case 'service_request_trace':
							$service_request_traceActiveClass = 'class="active"';
							break;
						case 'loan_facility_trace':
							$loan_facility_traceActiveClass = 'class="active"';
							break;
						case 'loan_consultation_trace':
							$loan_consultation_traceActiveClass = 'class="active"';
							break;
						case 'request_legal_consultation_trace':
							$request_legal_consultation_traceActiveClass = 'class="active"';
							break;
						case 'consolidation_trace':
							$loanconsoltraceActiveClass = 'class="active"';
							break;
						case 'Bank_trace':
							$banktraceActiveClass = 'class="active"';
							break;
						case 'Bank_administrative_user_trace':
							$bankadministrativeusertraceActiveClass = 'class="active"';	
							break;
						case 'Agency_trace':
							$agencytraceActiveClass = 'class="active"';	
							break;
						case 'Collection_agency_administrative_user_trace':
							$collectionagencyadministrativeusertraceActiveClass = 'class="active"';	
							break;
						case 'user_trace':
							$user_traceActiveClass = 'class="active"';
							$setting_traceActiveClass = 'class="menu-open" style="display: block;"';
							break;
						case 'chat_trace':
							$chatTraceActiveClass = 'class="active"';
							break;
						case 'Make_trace':
							$maketraceActiveClass = 'class="active"';
							break;
						case 'Platecode_trace':
							$platecodetraceActiveClass = 'class="active"';
							break;
						case 'Unknowncar_trace':
							$unknowncartraceActiveClass = 'class="active"';
							break;			
						default:
						if((isset($_REQUEST['hidLoanType']) && ($_REQUEST['hidLoanType']=='restructure')) || ($this->input->cookie('_rEsTrCtUrE') == 'restructure')){
							$hidLoanTypeCookie=$this->input->cookie('_rEsTrCtUrE');
							$loanrestrtraceActiveClass = 'class="active"';
						}else if((isset($_REQUEST['hidLoanType']) && ($_REQUEST['hidLoanType']=='settlement')) || ($this->input->cookie('_sEtTlEmEnT') == 'settlement')){
							$hidLoanTypeCookie=$this->input->cookie('_sEtTlEmEnT');
							$settlementActiveClass = 'class="active"';
						}	
					}
					
				?>
					<input type="hidden" name="hidLoanTypeCookie" id="hidLoanTypeCookie" value="<?php echo $hidLoanTypeCookie; ?>" />
					 <li <?php echo $car_traceActiveClass; ?>><a href="<?php echo base_url(); ?>car_trace"><img src="<?php echo base_url(); ?>skin/images/side_icon/car_trace.png" class="sidebar-icon" alt="Car Trace"> <span>Car Trace</span></a></li> 
					
					<!--li <?php echo $loanrestrtraceActiveClass; ?>><a href="javascript:void(0);" id ="loanrestrtrace" class="loantrace" value="restructure"><img src="<?php echo base_url(); ?>skin/images/loan-restructure.png" class="sidebar-icon" alt="Loan Restructure"><span onclick = "loantrace('restructure','_rEsTrCtUrE', 2592000, '/')" name="loantrace">Loan Restructure</span></a></li>
					
					<li <?php echo $settlementActiveClass; ?>><a href="javascript:void(0);" id ="loansettltrace" class="loantrace" value="settlement"><img src="<?php echo base_url(); ?>skin/images/loan-settlement.png" class="sidebar-icon" alt="Loan Settlement"><span onclick = "loantrace('settlement','_sEtTlEmEnT', 2592000, '/')" name="loantrace">Loan Settlement</span></a></li>
										
					<li <?php echo $loanconsoltraceActiveClass; ?>><a href="<?php echo base_url(); ?>consolidation_trace" class="loantrace"><img src="<?php echo base_url(); ?>skin/images/loan-consolidation.png" class="sidebar-icon" alt="Loan Consolidation"> <span>Loan Consolidation</span></a></li>
					
					<li <?php echo $service_request_traceActiveClass; ?>><a href="<?php echo base_url(); ?>service_request_trace"><img src="<?php echo base_url(); ?>skin/images/service-request.png" class="sidebar-icon" alt="Service Request"><span>Service Request</span></a></li> 
					
					<li <?php echo $loan_facility_traceActiveClass; ?>><a href="<?php echo base_url(); ?>loan_facility_trace"><img src="<?php echo base_url(); ?>skin/images/loan-facility.png" class="sidebar-icon" alt="Loan Facility"><span>Facility for Loan</span></a></li>
					
					<li <?php echo $loan_consultation_traceActiveClass; ?>><a href="<?php echo base_url(); ?>loan_consultation_trace"><img src="<?php echo base_url(); ?>skin/images/loan-consultation.png" class="sidebar-icon" alt="Loan Consultation"><span>Debt Consultation</span></a></li>
					
					<li <?php echo $request_legal_consultation_traceActiveClass; ?>><a href="<?php echo base_url(); ?>request_legal_consultation_trace"><img src="<?php echo base_url(); ?>skin/images/request-legal-consultation.png" class="sidebar-icon" alt="Request Legal Consultation"><span>Legal Consultation</span></a></li-->		
					
					<li <?php echo $user_traceActiveClass; ?>><a href="<?php echo base_url(); ?>user_trace"><img src="<?php echo base_url(); ?>skin/images/side_icon/users.png" class="sidebar-icon" alt="Users"><span>Users</span></a></li>	
					
					<li <?php echo $banktraceActiveClass; ?>><a href="<?php echo base_url(); ?>bank_trace"><img src="<?php echo base_url(); ?>skin/images/side_icon/banks.png" class="sidebar-icon" alt="Users"><span>Banks</span></a></li>		
					<li <?php echo $bankadministrativeusertraceActiveClass; ?>><a href="<?php echo base_url(); ?>bank_administrative_user_trace"><img src="<?php echo base_url(); ?>skin/images/side_icon/bankusers.png" class="sidebar-icon" alt="Users"><span>Bank users</span></a></li>		
					<li <?php echo $agencytraceActiveClass; ?>><a href="<?php echo base_url(); ?>agency_trace"><img src="<?php echo base_url(); ?>skin/images/side_icon/agency.png" class="sidebar-icon" alt="Users"><span>Agency</span></a></li>
					
					<li <?php echo $collectionagencyadministrativeusertraceActiveClass; ?>><a href="<?php echo base_url(); ?>collection_agency_administrative_user_trace"><img src="<?php echo base_url(); ?>skin/images/side_icon/agencyusers.png" class="sidebar-icon" alt="Users"><span>Agency users</span></a></li>
					
					<li <?php echo $car_listActiveClass; ?>><a href="<?php echo base_url(); ?>car_list"><img src="<?php echo base_url(); ?>skin/images/side_icon/cardatabase.png" class="sidebar-icon" alt="Car List"><span>Car Database</span></a></li>
					
					<li <?php echo $imported_carsActiveClass; ?>><a href="<?php echo base_url(); ?>imported_car"><img src="<?php echo base_url(); ?>skin/images/side_icon/importedcar.png" class="sidebar-icon" alt="Car List"><span>Imported Cars</span></a></li>
					
					<li <?php echo $imported_logsActiveClass; ?>><a href="<?php echo base_url(); ?>import_log"><img src="<?php echo base_url(); ?>skin/images/side_icon/log.png" class="sidebar-icon" alt="Car List"><span>Imported Cars Log</span></a></li>
					<li <?php echo $maketraceActiveClass; ?>><a href="<?php echo base_url(); ?>make_trace"><img src="<?php echo base_url(); ?>skin/images/side_icon/makes.png" class="sidebar-icon" alt="Makes"><span>Makes</span></a></li>
					<li <?php echo $platecodetraceActiveClass; ?>><a href="<?php echo base_url(); ?>platecode_trace"><img src="<?php echo base_url(); ?>skin/images/side_icon/platecode.png" class="sidebar-icon" alt="Platecode"><span>Plate Code</span></a></li>
					<li <?php echo $unknowncartraceActiveClass; ?>><a href="<?php echo base_url(); ?>unknowncar_trace"><img src="<?php echo base_url(); ?>skin/images/side_icon/unkonwncar.png" class="sidebar-icon" alt="Unknowncar"><span>Unknown Car</span></a></li>
					<!--li <?php echo $chatTraceActiveClass; ?>><a href="<?php echo base_url(); ?>chat_trace"><img src="<?php echo base_url(); ?>skin/images/user.png" class="sidebar-icon" alt="Users"><span>Chat Details</span></a></li-->
					<!--
					<li class="treeview">
						<a href="javascript:void(0);"><img src="<?php echo base_url(); ?>skin/images/settings.png" class="sidebar-icon" alt="Setting"><span> Setting</span>
						<span class="pull-right-container">
						<i class="fa fa-angle-down pull-right transition_all_01s"></i>
						</span>
						</a>
						<ul class="treeview-menu" <?php echo $setting_traceActiveClass; ?>>
						<li <?php echo $user_traceActiveClass; ?>><a href="<?php echo base_url(); ?>user_trace"><img src="<?php echo base_url(); ?>skin/images/user.png" class="sidebar-icon" alt="Users"><span>Users</span></a></li> 
						<li><a href="<?php echo base_url(); ?>user_trace"><i class="fa fa-link"></i> <span>Employee</span></a></li>
						</ul>
					</li>
					-->
				</ul> 
				<form name="frmLoanType" id="frmLoanType" method="post" action="<?php echo base_url(); ?>/loan_trace">
					<input type="hidden" name="hidLoanType" id="hidLoanType" value="" />
				</form>
			</section> 
			</aside>
