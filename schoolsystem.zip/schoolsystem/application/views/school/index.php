<div id="cat_data_id" class="">
<table border="1" id="cat_data_id_prv">
<tr><td colspan="7"><a class="edit" href="<?php echo base_url(); ?>school/addSchool">Add School</a></td>
	<td>
		<select name="catIdSearch" class="" id="catIdSearch" onChange="changeCat();">
			<option value="">Select one</option>
			<?php foreach($category as $key => $value){ ?>
				<option value="<?php echo $value->id; ?>"><?php echo $value->title; ?></option>
			<?php } ?>									
		</select>
	</td>	
</tr>
	<tr>
		<th>Title</th>
		<th>Category</th>
		<th>Short Description</th>
		<th>Description</th>
		<th>Image</th>
		<th>Author</th>
		<th>Created</th>
		<th>Action</th>
	</tr>	
	<?php
	if($articles){
		foreach ($articles as $article){ ?>
		<tr>
			<td><?php echo $article->title; ?></td>
			<td><?php echo $article->cat_name; ?></td>
			<td><?php echo $article->short_description; ?></td>
			<td><?php echo $article->description; ?></td>
			<td class="uploadedFileItem"><img src="uploads/<?php echo $article->image; ?>" alt=""/></td>
			<td><?php echo $article->first_name.' '.$article->last_name; ?></td>
			<td><?php echo date('d M Y',strtotime($article->record_date)); ?></td>
			<td><a class="edit" href="<?php echo base_url(); ?>blog/blogEdit/<?php echo $article->id; ?>">Edit</a>&nbsp;&nbsp;
			<button type="button" class="" onclick="deleteBlogData(<?php echo $article->id; ?>);">Delete</button>
			<!--a class="delete" href="<?php echo base_url(); ?>blog/blogDelete/<?php echo $article->id; ?>" onclick="return confirm('Are you sure you want to delete this?');">Delete</a--></td>
		</tr>
		<?php }}else{ ?>
			<tr>
				<td colspan="7"><?php echo 'Data not available'; ?></td>				
			</tr>		
	<?php } ?>	
</table>
</div>
