<form method="post">
  <div class="container">
    <h1>Edit School</h1>
    <hr>
	<label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" id="name" value="<?php echo $schoolData[0]->name; ?>" required>
	<label for="location"><b>Location</b></label>
    <input type="text" placeholder="Enter Location" name="location" id="location" value="<?php echo $schoolData[0]->location; ?>" required>
    <input type="hidden" name="school_id" id="school_id" value="<?php echo $schoolData[0]->id; ?>">
	<input type="hidden" name="user_id" id="user_id" value="<?php echo $schoolData[0]->user_id; ?>">
	<button type="submit" class="registerbtn" id="">Save</button>
  </div>
</form>