<div id="cat_data_id" class="">
<table border="1" id="schoollist">
	<table border="1" id="cat_data_id_prv">
		<tr><td colspan="6"><a class="edit" href="<?php echo base_url(); ?>Schools/create">Add School</a></td></tr>
		<form action="<?php echo base_url(); ?>Schools/allschool" method="post"> 
		<tr>
			<td colspan="3">
			<div class="input-group"> 
				<input type="text" name="name" class="form-control" placeholder="Name">
			</div>
			</td>
			<td colspan="3">
			<div class="input-group">
				<input type="submit" value="search" name="save"/>
			</div>
			</td>
			</tr>
        </form>
		<tr>
			<th>Sr.No.</th>
			<th>Name</th>
			<th>Location</th>
			<th>User Name</th>
			<th>Created</th>
			<th>Action</th>
		</tr>	
		<?php
		 // Set order
		 if($order == "asc"){
		   $order = "desc";
		 }else{
		   $order = "asc";
		 }
		if($schools){
			$sno = $row+1;
			foreach ($schools as $school){ 
		?>
		<tr>
			<td><?php echo $sno; ?></td>
			<td><?php echo $school->name; ?></td>
			<td><?php echo $school->location; ?></td>
			<td><?php echo $school->first_name.' '.$school->last_name; ?></td>
			<td><?php echo date('d M Y',strtotime($school->record_date)); ?></td>
			<td>
				<a class="edit" href="<?php echo base_url(); ?>schools/edit/<?php echo $school->id; ?>">Edit</a>&nbsp;&nbsp;
				<a class="delete" name="delete" onclick="return confirm('Are you sure you want to delete this?');" href="<?php echo base_url();?>schools/delete/<?php echo $school->id;?>" >Delete</a>
			</td>
		</tr>
		<?php $sno++;}}else{ ?>
			<tr>
				<td colspan="5"><?php echo 'Data not available'; ?></td>				
			</tr>		
		<?php }
     ?>	
	</table>
	<!-- Paginate -->
    <div style='margin-top: 10px;'>
      <?= $pagination; ?>
    </div>
</div>