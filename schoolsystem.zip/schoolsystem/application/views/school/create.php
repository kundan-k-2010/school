<form method="post">
  <div class="container">
    <h1>Add School</h1>
    <p>Please fill in this form to create an school.</p>
    <hr>
	<label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" id="name" required>
	<label for="location"><b>Location</b></label>
    <input type="text" placeholder="Enter Location" name="location" id="location" required>
	<input type="hidden" name="user_id" id="user_id" value="<?php echo $userId; ?>">
    <button type="submit" class="registerbtn" id="">Add</button>
  </div>
</form>