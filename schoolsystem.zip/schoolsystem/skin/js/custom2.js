// JavaScript Document
$(document).ready(function () { 
	updateConfig();  
	 $('#frmLoanType').append('<input type="hidden" name="pagination_total" value='+$('.pagination_total').val()+'>');
	 /**************************************************************************
	 * Purpose: Navigate user on the requested page
	 * Inputs:	null
	 * Return:	null
	 * Created by:	Bhakti S.
	 *************************************************************************/
	 
	 /* variable initialization */
	var intPageNumber = 1;
	/* if current page number record set found then do needful */
	if($('#txtCurrentPage').length > 0){
		/* Setting the page number */
		intPageNumber	= $('#txtCurrentPage').val();
	}
	$('#frmSearch').append('<input type="hidden" name="txtCurrentPageNumber" id="txtCurrentPageNumber" value="'+intPageNumber+'">');
	var intDefaultPerPageNumber = 3;
	/* if page number drop down found then do needful */
	if($('#cPerPageRecords').length > 0){
		/* Setting the per page record number */
		intDefaultPerPageNumber = $('#cPerPageRecords').val();
	}
	
	/* Setting default number of pages  */
	$('#frmSearch').append('<input type="hidden" name="per_page" id="per_page" value="'+intDefaultPerPageNumber+'" />');
	$('#txtCurrentPage').keydown(function(event){
		if(event.which == 13){
			if(isNaN($(this).val())){
				alert("Please enter valid page number.");
			}else{
				if(parseInt($('#txtTotalPages').val()) < parseInt($(this).val())){
					alert("Enter valid page number.");
				}else{
					setPageNumber($(this).val());
				}
			}
		}
	});
	
	/**************************************************************************
	 * Purpose:	Setting the record per page.
	 * Inputs:	null
	 * Return:	null
	 * Created by:	Bhakti S.
	 *************************************************************************/
	$('#cPerPageRecords').change(function(){
		$('#per_page').val($(this).val());
		$('#txtCurrentPageNumber').val('1');
		$('#frmSearch').append('<input type="hidden" name="loanType" value="'+$('#hidLoanTypeCookie').val()+'"/>');
		
		$( "input[name^='search']").each(function(){
			$('#frmSearch').append('<input type="hidden" name="'+$(this).attr('name')+'" value="'+$(this).val()+'"/>');
		});
		$( "select[name^='search']").each(function(){
			$('#frmSearch').append('<input type="hidden" name="'+$(this).attr('name')+'" value="'+$(this).val()+'"/>');
		});
		
		$('#frmSearch').submit();
	});
	
	/**************************************************************************
	 * Purpose:	setting cookie for side menu
	 * Inputs:	null
	 * Return:	null
	 * Created by:	Bhakti S.
	 *************************************************************************/
	$('.sidebar-menu').find('a').each(function(){
		$(this).click(function(){
		if(!($(this).hasClass('loantrace'))){
			document.cookie = "_rEsTrCtUrE=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
			document.cookie = "_sEtTlEmEnT=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
			document.cookie = "_cOnSoLiDaTiOn=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
		}
		});
	});
	
	
	$('.date-time-only').each(function(){
		$('#'+$(this).attr('id')).datetimepicker({
			timepicker:false,
			format:'Y-m-d',
			formatDate:'Y-m-d',
			//maxDate:maxAsssignDate,
			closeOnDateSelect:true,	
		});
	});
	
	
	if($('#controller_name').length>0){
		/* Search functionality */
		searchDetails();
		/* date picker */
		dateDetails();
		updateConfig();
		/* view all details on clik */
		viewAllDetails();
		/* view claim by details on click */
		viewClaimByDetails();
		/* view user details on click */
		viewUserDetails();		
	}
	
	/* horizontal scroll bar */
	setNiceScroll();
	
	//$("html").niceScroll({cursorwidth:'12px', autohidemode:false, cursorborderradius:'4px', });		
});

/**************************************************************************
* Purpose 		: Download excel sheet.
* Created By 	: Kundan Kumar.
/**************************************************************************/
function exceldownload(loanType,orderId){
	var data={};
	if(loanType == 'chatting'){
		var strExecutionURL = base_url+$('#controller_name').val()+'/viewChat_trace';
		data['orderId']= orderId;
	}else{
		var strExecutionURL = base_url+$('#controller_name').val();
	}
	data['loanType']= loanType;	
	data['txtExcel']= 'excel';	
	$('.data_load').find( "input[name^='search']").each(function(){
		data[$(this).attr('name')] = $(this).val();		
	});
	$('.data_load').find( "select[name^='search']").each(function(){
		data[$(this).attr('name')] = $(this).val();
	});
	
	$.ajax({ 
		type: "POST",
			url: strExecutionURL,
			data:data,
			success: function(response){
				if(loanType == 'chatting'){
					$('.div-chat-msg').html(response);
				}else{				
					$('.div-msg').html(response);
				}				
				return;
			},
			error: function(){
				return false;		
			}	
	});
}
/**************************************************************************
* Purpose 		: Display page according to loan type.
* Created By 	: Kundan Kumar.
/**************************************************************************/
function loantrace(loanType,value, days2expire, path){
	document.cookie = "_rEsTrCtUrE=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
	document.cookie = "_sEtTlEmEnT=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
	document.cookie = "_cOnSoLiDaTiOn=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
	
	$('#hidLoanType').val(loanType);
	var date = new Date();
	date.setTime(date.getTime() + (days2expire * 24 * 60 * 60 * 1000));
	var expires = date.toUTCString();
	
	document.cookie = value + '=' + loanType + ';' +
					   'expires=' + expires + ';' +
					   'path=' + path + ';';
					   
	$('#frmLoanType').attr('action',base_url+'loan_trace').submit(		
	);	
}
/**************************************************************************
* Purpose 		: Search Functionality
* Created By 	: Bhakti S.
/**************************************************************************/
function searchDetails(){
	$('#myModal').removeClass('changestatus');	
	var url_name = base_url+$('#controller_name').val();	
	$('.search_country_name').change(function(e) {						
		var url_name = base_url+"Bank_trace/StateValue";
		var countryId = $(this).val();
		$.ajax({
				url: url_name,
				type: "POST",
				data:{'countryId':countryId},
				success: function(response){			
					$('.search_state_name').html(response);																
				}
			}); 
	}); 
	$('.search_state_name').change(function(e) {				
		var url_name = base_url+"Bank_trace/CityValue";
		var stateId = $(this).val();
		$.ajax({
				url: url_name,
				type: "POST",
				data:{'stateId':stateId},
				success: function(response){			
					$('.search_city_name').html(response);																
				}
			}); 
	}); 
	$('.search_city_name').change(function(e) {				
			var url_name = base_url+"Bank_trace/BankValue";
			var cityId = $(this).val();
			$.ajax({
					url: url_name,
					type: "POST",
					data:{'cityId':cityId},
					success: function(response){			
						$('.search_bank_name').html(response);																
					}
				}); 
	});
	$('.search_city_name').change(function(e) {				
			var url_name = base_url+"Agency_trace/AgencyValue";
			var cityId = $(this).val();
			$.ajax({
					url: url_name,
					type: "POST",
					data:{'cityId':cityId},
					success: function(response){			
						$('.search_agency_name').html(response);																
					}
				}); 
	});
	$('#searchFormSubmit').submit(function(e){
				var ajaxData={};
				var formElements = $(this).serializeArray();
				$.each(formElements,function(key,val){
					ajaxData[formElements[key].name] = formElements[key].value;
					/* $.each(ajaxData,function(key,val){
						ajaxData[ajaxData[key].name] = ajaxData[key].value;
					}); */
				});
				ajaxData['search_ajax'] = 'search_ajax';
				ajaxData['reset_search'] = 'reset_search';
				e.preventDefault();
				var url_name = base_url+$('#controller_name').val();
				$.ajax({
					type:'POST',
					data:ajaxData,
					url:url_name,
					success:function(response) {
					  $('#myModal').modal('hide');
					   $( '.modal-backdrop' ).hide();
					  $('.content-wrapper').html(response);
					  $('body').removeClass('modal-open');
					  /* Search functionality */
						searchDetails();
						/* date picker */
						dateDetails();
						updateConfig();
						/* view all details on clik */
						viewAllDetails();
						/* view claim by details on click */
						viewClaimByDetails();
						/* view user details on click */
						viewUserDetails();						
						setNiceScroll();
						$('#txtCurrentPage').keydown(function(event){
							if(event.which == 13){
								if(isNaN($(this).val())){
									alert("Please enter valid page number.");
								}else{
									if(parseInt($('#txtTotalPages').val()) < parseInt($(this).val())){
										alert("Enter valid page number.");
									}else{
										setPageNumber($(this).val());
									}
								}
							}
						});
						$('#cPerPageRecords').change(function(){
							$('#per_page').val($(this).val());
							$('#txtCurrentPageNumber').val('1');
							$('#frmSearch').append('<input type="hidden" name="loanType" value="'+$('#hidLoanTypeCookie').val()+'"/>');
		
							$( "input[name^='search']").each(function(){
								$('#frmSearch').append('<input type="hidden" name="'+$(this).attr('name')+'" value="'+$(this).val()+'"/>');
							});
							$( "select[name^='search']").each(function(){
								$('#frmSearch').append('<input type="hidden" name="'+$(this).attr('name')+'" value="'+$(this).val()+'"/>');
							});
							$('#frmSearch').submit();
						});
					  return false;
					}
				});
			});	
}
/**************************************************************************
* Purpose 		: Date Picker
* Created By 	: Kundan Kumar.
/**************************************************************************/
function dateDetails(){
	$('.date-time-only').each(function(){
		$('#'+$(this).attr('id')).datetimepicker({
			timepicker:false,
			format:'Y-m-d',
			formatDate:'Y-m-d',
			closeOnDateSelect:true,	
		});
	});	
}

function updateConfig() {
	$('.config-demo').each(function(){
		$(this).daterangepicker({ 
			autoUpdateInput: false,
			showDropdowns: true,
			timePicker24Hour: true,
			  locale: {
				  cancelLabel: 'Clear',
				  format: 'YYYY/MM/DD'
			  }
		}); 
		$(this).on('apply.daterangepicker', function(ev, picker) {
			  $(this).val(picker.startDate.format('YYYY/MM/DD') + ' - ' + picker.endDate.format('YYYY/MM/DD'));
		});

		$(this).on('cancel.daterangepicker', function(ev, picker) {
			  $(this).val('');
		});
	});
	$('.config-demo-time').each(function(){
		$(this).daterangepicker({ 
			autoUpdateInput: false,
			timePicker: true,
			timePickerSeconds: true,
			timePickerIncrement: 1,
			showDropdowns: true,
			timePicker24Hour: true,
			locale: {
				cancelLabel: 'Clear',
				format: 'YYYY/MM/DD 00:00:00'
			}
		}); 
		$(this).on('apply.daterangepicker', function(ev, picker) {
			  $(this).val(picker.startDate.format('YYYY/MM/DD h:mm:ss') + ' - ' + picker.endDate.format('YYYY/MM/DD h:mm:ss'));
		});

		$(this).on('cancel.daterangepicker', function(ev, picker) {
			  $(this).val('');
		});
	});
	
}	
/**************************************************************************
* Purpose 		: View All Details On Click
* Created By 	: Bhakti S.
/**************************************************************************/
function viewAllDetails(){
	$('#myModal').removeClass('changestatus');
	var url_name = base_url+$('#controller_name').val()+"/view"+$('#controller_name').val();
	$(".viewAllDetails").each(function(){
		$(this).click(function(){
			data = {};
			var orderId = $(this).attr('value');
			data['orderId'] = orderId;
			$.ajax({ 
				type: "POST",
					url: url_name,
					data:data,
					success: function(response){
						$('#myModal').modal({show: true})
						$('.modal-content').html(response);
						$('#myModal').removeClass('changestatus');
						$('#myModal').on('hidden.bs.modal', function () {
							$('#myModal').modal({show: false})
							$(".modal-body").empty()
							$( '.modal' ).modal( 'hide' ).data( 'bs.modal', null );
							$( '.modal-backdrop' ).hide();
							$( 'body' ).removeClass( "modal-open" );
						});
					},
					error: function(){
						return false;		
					}	
			});
		});
	});
}
/**************************************************************************
* Purpose 		: View All Claim By Details On Click
* Created By 	: Bhakti S.
/**************************************************************************/
function viewClaimByDetails(){
	$('#myModal').removeClass('changestatus');
	$(".claimBy").each(function(){
		$(this).click(function(e){
			e.preventDefault();
			data = {};
			var claimDetails = ($(this).attr('value')).split('~');
			var claimType = claimDetails[0];
			var orderId = claimDetails[1];
			var strExecutionURL	= base_url+"Car_trace/viewClaimDetails";
			
			data['claimType'] = claimType;
			data['orderId'] = orderId;
			
			$.ajax({ 
				type: "POST",
					url: strExecutionURL,
					data:data,
					success: function(response){
						$('#myModal').modal({show: true});
						$('.modal-content').html(response);
						$('#myModal').on('hidden.bs.modal', function () {
							$('#myModal').modal({show: false})
							$(".modal-body").empty()
							$( '.modal' ).modal( 'hide' ).data( 'bs.modal', null );
							$( '.modal-backdrop' ).hide();
							$( 'body' ).removeClass( "modal-open" );
						});
					},
					error: function(){
						return false;		
					}	
			});
		});
	});
}
/**************************************************************************
* Purpose 		: View All User Details On Click
* Created By 	: Bhakti S.
/**************************************************************************/
function viewUserDetails(){
	$('#myModal').removeClass('changestatus');
	$(".viewUserDetails").each(function(){
		$(this).click(function(){
			var url_name = base_url+"User_trace/viewUserDetails";
			var data = {};
			data['userId'] = $(this).attr('value');
			$.ajax({
				type : 'POST',
				url : url_name,
				data : data,
				success : function(response){
					$('#myModal').modal({show: true})
					$('.modal-content').html(response);
					$('#myModal').removeClass('changestatus');
					$('#myModal').on('hidden.bs.modal', function () {
						$('#myModal').modal({show: false})
						$(".modal-body").empty()
						$( '.modal' ).modal( 'hide' ).data( 'bs.modal', null );
						$( '.modal-backdrop' ).hide();
						$( 'body' ).removeClass( "modal-open" );
					});
				},
				error : function(){
					return false;
				}
			});
		});
	});
}

/**************************************************************************
 * Purpose	:	Set page number to be viewed
 * Inputs	:	None
 * Return	:	None
 * Created by:	Bhakti S.
 *************************************************************************/
function setPageNumber(pIntPageNumber){
	$('#txtCurrentPageNumber').val(pIntPageNumber);
	var data={};
	data['txtCurrentPageNumber']=pIntPageNumber;
	if($('#cPerPageRecords').length > 0){
		/* Setting the per page record number */
		intDefaultPerPageNumber = $('#cPerPageRecords').val();
	}
	data['per_page'] = intDefaultPerPageNumber;
	data['loanType']=$('#hidLoanTypeCookie').val();
	
	
	data['search_ajax'] = 'search_ajax';
	
	$( "input[name^='search']").each(function(){
		data[$(this).attr('name')] = $(this).val();
	});
	$( "select[name^='search']").each(function(){
		data[$(this).attr('name')] = $(this).val();
	});
		
		
	var strExecutionURL = base_url+$('#controller_name').val();
	$.ajax({
		type:'post',
		url:strExecutionURL,
		data:data,
		success:function(response){
			$('.content-wrapper').html('');
			$('.content-wrapper').html(response);
			/* Search functionality */
			searchDetails();
			/* date picker */
			dateDetails();
			updateConfig();
			/* view all details on clik */
			viewAllDetails();
			/* view claim by details on click */
			viewClaimByDetails();
			/* view user details on click */
			viewUserDetails();
			setNiceScroll();
			//$('.main_wapper').niceScroll().updateScrollBar();
			
			$('#txtCurrentPage').keydown(function(event){
				if(event.which == 13){
					if(isNaN($(this).val())){
						alert("Please enter valid page number.");
					}else{
						if(parseInt($('#txtTotalPages').val()) < parseInt($(this).val())){
							alert("Enter valid page number.");
						}else{
							setPageNumber($(this).val());
						}
					}
				}
			});
			$('#cPerPageRecords').change(function(){
				$('#per_page').val($(this).val());
				$('#txtCurrentPageNumber').val('1');
				$('#frmSearch').append('<input type="hidden" name="loanType" value="'+$('#hidLoanTypeCookie').val()+'"/>');
		
				$( "input[name^='search']").each(function(){
					$('#frmSearch').append('<input type="hidden" name="'+$(this).attr('name')+'" value="'+$(this).val()+'"/>');
				});
				$( "select[name^='search']").each(function(){
					$('#frmSearch').append('<input type="hidden" name="'+$(this).attr('name')+'" value="'+$(this).val()+'"/>');
				});
				$('#frmSearch').submit();
			});
		},
		error:function(){
			return false;
		}	
	});
}
/**************************************************************************
 Purpose 		: Checking all the checkbox having same name as attribute as that of supplied obj
 Inputs  		: source_obj :: Checkbox obj
 Return 		: none.
 Created By 	: Kundan Kumar
/**************************************************************************/
function check_all( source_obj ){
	var checkboxes_name = source_obj.getAttribute('name');
	var checkboxes = document.getElementsByName(checkboxes_name);	
	for(var i=0, n=checkboxes.length;i<n;i++) {
		checkboxes[i].checked = source_obj.checked;
		 if(source_obj.checked == true){
			$('#modalClose').attr('href', '#myModal');
			$('#modalClosedeact').attr('href', '#myModal');
			$('#loanSubmit').removeAttr('disabled');	
		}
		if(source_obj.checked == false){	
			$('#modalClose').attr('href', '');	
			$('#modalClosedeact').attr('href', '');	
			$('#loanSubmit').attr("disabled", "disabled");
		}					
	}	
}
function check_other(){
	var blnSelected 	= false;	
	$('.table').find('input[type="checkbox"]').each(function(){
		if($(this).is(':checked') && (!blnSelected)){
			blnSelected = true;							
		}			
	});						
	if(!blnSelected){
		$('#loanSubmit').attr("disabled", "disabled");
		$('#modalClose').attr('href', '');
		$('#modalClosedeact').attr('href', '');
	}else{
		$('#loanSubmit').removeAttr('disabled');
		$('#modalClose').attr('href', '#myModal');
		$('#modalClosedeact').attr('href', '#myModal');
	}			
}
/**************************************************************************
 Purpose 		: Change status 
 Inputs  		: ids
 Return 		: none.
 Created By 	: Kundan Kumar
/**************************************************************************/
function changeStatus( statusType, allLoan, contr, status){		
	$('#myModal').addClass('changestatus');
	var blnSelected 	= false;
	var intOrderCodeArr	= [];
	$('.table').find('input[type="checkbox"]').each(function(){
		if($(this).is(':checked') && (!blnSelected)){
				blnSelected = true;	
				intOrderCodeArr	= [];				
			}
		if($(this).is(':checked')){
			intOrderCodeArr.push($(this).val());			
		}		
	});	
	var intOrderUniqueCodeArr = {};
	intOrderUniqueCodeArr = jQuery.unique( intOrderCodeArr );
	
	if(!blnSelected){
		alert('Please select at least one record to change status');
		return false;		
	}else{		
		if(contr == 'carList'){
			var url_name = base_url+"Car_list/showStatus";	
			var data_details = {'statusType':statusType,'orderIds':intOrderUniqueCodeArr,'allLoan':allLoan,'status':status};
		}else{
			var url_name = base_url+"Car_trace/showStatus";	
			var data_details = {'statusType':statusType,'orderIds':intOrderUniqueCodeArr,'allLoan':allLoan};	
		}
		$.ajax({
			url: url_name,
			type: "POST",
			data: data_details,
			success: function(response){					
				$('.modal-content').html(response);
				$('#frmStatusChange').submit(function(e){
					e.preventDefault();
					var ajaxData = {};
					$('input[name^="search"]').each(function(e){
						ajaxData[$(this).attr('name')]=$(this).val();
						
					});
					$('select[name^="search"]').each(function(e){
						ajaxData[$(this).attr('name')]=$(this).val();
						
					});
					var formElements = $(this).serializeArray();
					$.each(formElements,function(key,val){
						ajaxData[formElements[key].name] = formElements[key].value;
					});
					 /* variable initialization */
					var intPageNumber = 1;
					/* if current page number record set found then do needful */
					if($('#txtCurrentPage').length > 0){
						/* Setting the page number */
						intPageNumber	= $('#txtCurrentPage').val();
					}
					
					ajaxData['txtCurrentPageNumber'] = intPageNumber;
					ajaxData['search_ajax'] = 'search_ajax';
					ajaxData['change_status'] = 'change_status';
					
					var url_name = base_url+$('#controller_name').val();
					$.ajax({
						type:'POST',
						data:ajaxData,
						url:url_name,
						success:function(response) {
						  $('#myModal').modal('hide');
						  $('.content-wrapper').html(response);
						  $('body').removeClass('modal-open');
						  /* Search functionality */
							searchDetails();
							/* date picker */
							dateDetails();
							updateConfig();
							/* view all details on clik */
							viewAllDetails();
							/* view claim by details on click */
							viewClaimByDetails();
							/* view user details on click */
							viewUserDetails();
							setNiceScroll();
							$('#txtCurrentPage').keydown(function(event){
								if(event.which == 13){
									if(isNaN($(this).val())){
										alert("Please enter valid page number.");
									}else{
										if(parseInt($('#txtTotalPages').val()) < parseInt($(this).val())){
											alert("Enter valid page number.");
										}else{
											setPageNumber($(this).val());
										}
									}
								}
							});
							$('#cPerPageRecords').change(function(){
								$('#per_page').val($(this).val());
								$('#txtCurrentPageNumber').val('1');
								$('#frmSearch').append('<input type="hidden" name="loanType" value="'+$('#hidLoanTypeCookie').val()+'"/>');
			
								$( "input[name^='search']").each(function(){
									$('#frmSearch').append('<input type="hidden" name="'+$(this).attr('name')+'" value="'+$(this).val()+'"/>');
								});
								$( "select[name^='search']").each(function(){
									$('#frmSearch').append('<input type="hidden" name="'+$(this).attr('name')+'" value="'+$(this).val()+'"/>');
								});
								$('#frmSearch').submit();
							});
						  return false;
						}
					});
				});
			}
		}); 
	}		
}
/**************************************************************************
 Purpose 		: Edit Data 
 Inputs  		: id
 Return 		: none.
 Created By 	: Kundan Kumar
/**************************************************************************/
	function editData(dataId,mName){
		$('#myModal').addClass('changestatus');	
		if(mName == '/Bank/'){
			var url_name = base_url+"Bank_trace/editBank";
		}else if(mName == '/Administrator/'){
			var url_name = base_url+"Bank_administrative_user_trace/editBankAministrator";
		}else if(mName == '/Agency/'){
			var url_name = base_url+"Agency_trace/editAgency";	
		}else if(mName == '/Agency Administrator/'){
			var url_name = base_url+"Collection_agency_administrative_user_trace/editAgencyAministrator";
		}else if(mName == '/Make/'){
			var url_name = base_url+"Make_trace/editMake";
		}else if(mName == '/Platecode/'){
			var url_name = base_url+"Platecode_trace/editPlatecode";			
		} 
		$.ajax({
			url: url_name,
			type: "POST",
			data:{'dataId':dataId},
			success: function(response){				
				$('.modal-content').html(response);				
				$('.country_id').click(function(e) {						
					var url_name = base_url+"Bank_trace/CountryValue";
					var pIntId = $(this).val();
					$.ajax({
							url: url_name,
							type: "POST",
							data:{'pIntId':pIntId},
							success: function(response){			
								$('.country_id').html(response);																
							}
						}); 
				}); 
				$('.country_id').change(function(e) {						
					var url_name = base_url+"Bank_trace/StateValue";
					var countryId = $(this).val();
					$.ajax({
							url: url_name,
							type: "POST",
							data:{'countryId':countryId},
							success: function(response){			
								$('.state_id').html(response);																
							}
						}); 
				}); 
				$('.state_id').click(function(e) {					
						var url_name = base_url+"Bank_trace/StateValue";
						var pIntId = $(this).val();
						var countryId = $('.country_id').val();
						$.ajax({
								url: url_name,
								type: "POST",
								data:{'countryId':countryId,'pIntId':pIntId},
								success: function(response){			
									$('.state_id').html(response);																
								}
							}); 					
				});    
				$('.state_id').change(function(e) {	
					var url_name = base_url+"Bank_trace/CityValue";
					var stateId = $(this).val();
					$.ajax({
							url: url_name,
							type: "POST",
							data:{'stateId':stateId},
							success: function(response){			
								$('.city_id').html(response);																
							}
						}); 
				});
				$('.country_code').click(function(e) {					
						var url_name = base_url+"Bank_trace/CountryCodeValue";
						var pIntId = $(this).val();
						$.ajax({
								url: url_name,
								type: "POST",
								data:{'pIntId':pIntId},
								success: function(response){			
									$('.country_code').html(response);																
								}
							}); 					
				});
				$('.parent_id').click(function(e) {					
						var url_name = base_url+"Make_trace/ParentValue";
						var pIntId = $(this).val();
						$.ajax({
								url: url_name,
								type: "POST",
								data:{'pIntId':pIntId},
								success: function(response){			
									$('.parent_id').html(response);																
								}
							}); 					
				});  				
				$('.car_type').click(function(e) {					
						var url_name = base_url+"Make_trace/CarTypeValue";
						var pIntId = $(this).val();
						if(pIntId == 0){
							$('.parent_id').attr('disabled','disabled');
						}else if(pIntId == 1){						
							$('.parent_id').removeAttr('disabled');
						}	
						$.ajax({
								url: url_name,
								type: "POST",
								data:{'pIntId':pIntId},
								success: function(response){			
									$('.car_type').html(response);											
								}
							}); 					
				});  				
				if((mName == '/Administrator/')||(mName == '/Agency Administrator/')){	
					$('.city_id').click(function(e) {					
						var url_name = base_url+"Bank_trace/CityValue";
						var pIntId = $(this).val();
						var stateId = $('.state_id').val();
						$.ajax({
								url: url_name,
								type: "POST",
								data:{'stateId':stateId,'pIntId':pIntId},
								success: function(response){			
									$('.city_id').html(response);																
								}
							}); 					
					});  
				}
				if((mName == '/Administrator/')){		
					$('.city_id').change(function(e) {				
						var url_name = base_url+"Bank_trace/BankValue";
						var cityId = $(this).val();
						$.ajax({
								url: url_name,
								type: "POST",
								data:{'cityId':cityId},
								success: function(response){			
									$('.bank_id').html(response);																
								}
							}); 
					}); 
					$('.bank_id').click(function(e) {					
						var url_name = base_url+"Bank_trace/BankValue";
						var pIntId = $(this).val();
						var cityId = $('.city_id').val();
						$.ajax({
								url: url_name,
								type: "POST",
								data:{'cityId':cityId,'pIntId':pIntId},
								success: function(response){			
									$('.bank_id').html(response);																
								}
							}); 					
					});  
				}
				if((mName == '/Agency Administrator/')){		
					$('.city_id').change(function(e) {				
						var url_name = base_url+"Agency_trace/AgencyValue";
						var cityId = $(this).val();
						$.ajax({
								url: url_name,
								type: "POST",
								data:{'cityId':cityId},
								success: function(response){			
									$('.agency_id').html(response);																
								}
							}); 
					}); 
					$('.agency_id').click(function(e) {					
						var url_name = base_url+"Agency_trace/AgencyValue";
						var pIntId = $(this).val();
						var cityId = $('.city_id').val();
						$.ajax({
								url: url_name,
								type: "POST",
								data:{'cityId':cityId,'pIntId':pIntId},
								success: function(response){			
									$('.agency_id').html(response);																
								}
							}); 					
					});  
				}
				$('#frmEditData').submit(function(e){					
					e.preventDefault();
					if(!(validateFormElement('frmEditData'))){
						return false;
					}
					var ajaxData = {};
					$('input[name^="search"]').each(function(e){
						ajaxData[$(this).attr('name')]=$(this).val();						
					});
					$('select[name^="search"]').each(function(e){
						ajaxData[$(this).attr('name')]=$(this).val();						
					});
					var formElements = $(this).serializeArray();
					$.each(formElements,function(key,val){
						ajaxData[formElements[key].name] = formElements[key].value;
					});
					 /* variable initialization */
					var intPageNumber = 1;
					/* if current page number record set found then do needful */
					if($('#txtCurrentPage').length > 0){
						/* Setting the page number */
						intPageNumber	= $('#txtCurrentPage').val();
					}
					
					ajaxData['txtCurrentPageNumber'] = intPageNumber;
					ajaxData['search_ajax'] = 'search_ajax';
					if(mName == '/Bank/'){
						ajaxData['change_status'] = 'edit_bank';
						ajaxData['dataId'] = dataId;
					}else if(mName == '/Administrator/'){
						ajaxData['change_status'] = 'edit_administrator';
						ajaxData['dataId'] = dataId;						
					}else if(mName == '/Agency/'){
						ajaxData['change_status'] = 'edit_agency';
						ajaxData['dataId'] = dataId;
					}else if(mName == '/Agency Administrator/'){
						ajaxData['change_status'] = 'edit_agency_administrator';
						ajaxData['dataId'] = dataId;
					}else if(mName == '/Make/'){
						ajaxData['change_status'] = 'edit_make';
						ajaxData['dataId'] = dataId;
					}else if(mName == '/Platecode/'){
						ajaxData['change_status'] = 'edit_platecode';
						ajaxData['dataId'] = dataId;						
					}
					var url_name = base_url+$('#controller_name').val();
					$.ajax({
						type:'POST',
						data:ajaxData,
						url:url_name,
						success:function(response) {
						  $('#myModal').modal('hide');
						  $( '.modal-backdrop' ).hide();
						  $('.content-wrapper').html(response);
						  $('body').removeClass('modal-open');
						  /* Search functionality */
							searchDetails();
							/* date picker */
							dateDetails();
							updateConfig();
							/* view all details on clik */
							viewAllDetails();
							/* view claim by details on click */
							viewClaimByDetails();
							/* view user details on click */
							viewUserDetails();							
							setNiceScroll();
							$('#txtCurrentPage').keydown(function(event){
								if(event.which == 13){
									if(isNaN($(this).val())){
										alert("Please enter valid page number.");
									}else{
										if(parseInt($('#txtTotalPages').val()) < parseInt($(this).val())){
											alert("Enter valid page number.");
										}else{
											setPageNumber($(this).val());
										}
									}
								}
							});
							$('#cPerPageRecords').change(function(){
								$('#per_page').val($(this).val());
								$('#txtCurrentPageNumber').val('1');
								
								$( "input[name^='search']").each(function(){
									$('#frmSearch').append('<input type="hidden" name="'+$(this).attr('name')+'" value="'+$(this).val()+'"/>');
								});
								$( "select[name^='search']").each(function(){
									$('#frmSearch').append('<input type="hidden" name="'+$(this).attr('name')+'" value="'+$(this).val()+'"/>');
								});
								$('#frmSearch').submit();
							});
						  return false;
						}
					});
				});
			}
		}); 	
	}
/**************************************************************************
 Purpose 		: Add Data 
 Inputs  		: none.
 Return 		: none.
 Created By 	: Kundan Kumar
/**************************************************************************/
	function addData(mName){
		switch(mName){
			case 'Bank':
				var url_name = base_url+"Bank_trace/addBank";
				break;
			case 'Administrator':
				var url_name = base_url+"Bank_administrative_user_trace/addBankAdministrator";
				break;
			case 'Agency':
				var url_name = base_url+"Agency_trace/addCollectionAgency";
				break;
			case 'Agency Administrator':
				var url_name = base_url+"Collection_agency_administrative_user_trace/addCollectionAgencyAdministrator";	
				break;
			case 'Make':
				var url_name = base_url+"Make_trace/addMake";
				break;
			case 'Platecode':
				var url_name = base_url+"Platecode_trace/addPlatecode";
				break;	
		}		
		$('#myModal').addClass('changestatus');
		$.ajax({
			url: url_name,
			type: "POST",
			success: function(response){				
				$('.modal-content').html(response);				
					$('.country_id').change(function(e) {						
						var url_name = base_url+"Bank_trace/StateValue";
						var countryId = $(this).val();
						$.ajax({
								url: url_name,
								type: "POST",
								data:{'countryId':countryId},
								success: function(response){			
									$('.state_id').html(response);																
								}
							}); 
					}); 
					$('.state_id').change(function(e) {				
						var url_name = base_url+"Bank_trace/CityValue";
						var stateId = $(this).val();
						$.ajax({
								url: url_name,
								type: "POST",
								data:{'stateId':stateId},
								success: function(response){			
									$('.city_id').html(response);																
								}
							}); 
					});
					if(mName == 'Administrator'){	
						$('.city_id').change(function(e) {				
							var url_name = base_url+"Bank_trace/BankValue";
							var cityId = $(this).val();
							$.ajax({
									url: url_name,
									type: "POST",
									data:{'cityId':cityId},
									success: function(response){			
										$('.bank_id').html(response);																
									}
								}); 
						}); 
					}
					$('.car_type').change(function(e) {
						var typeId = $(this).val();
						if(typeId == 0){
							$('.parent_id').attr('disabled','disabled');
						}else if(typeId == 1){						
							$('.parent_id').removeAttr('disabled');
						}	
					});
					if(mName == 'Agency Administrator'){	
						$('.city_id').change(function(e) {				
							var url_name = base_url+"Agency_trace/AgencyValue";
							var cityId = $(this).val();
							$.ajax({
									url: url_name,
									type: "POST",
									data:{'cityId':cityId},
									success: function(response){			
										$('.agency_id').html(response);																
									}
								}); 
						}); 
					}
				$('#frmDataAdd').submit(function(e){
					if(!(validateFormElement('frmDataAdd'))){
						return false;
					}  
					e.preventDefault();
					var ajaxData = {};
					$('input[name^="search"]').each(function(e){
						ajaxData[$(this).attr('name')]=$(this).val();						
					});
					$('select[name^="search"]').each(function(e){
						ajaxData[$(this).attr('name')]=$(this).val();						
					});
					var formElements = $(this).serializeArray();
					$.each(formElements,function(key,val){
						ajaxData[formElements[key].name] = formElements[key].value;
					});
					 /* variable initialization */
					var intPageNumber = 1;
					/* if current page number record set found then do needful */
					if($('#txtCurrentPage').length > 0){
						/* Setting the page number */
						intPageNumber	= $('#txtCurrentPage').val();
					}
					
					ajaxData['txtCurrentPageNumber'] = intPageNumber;
					ajaxData['search_ajax'] = 'search_ajax';
					switch(mName){
						case 'Bank':
							ajaxData['change_status'] = 'add_bank';
							var msg = 'Bank added successfully.';
							break;
						case 'Administrator':
							ajaxData['change_status'] = 'add_administrator';
							//var url_name = base_url+"Bank_administrative_user_trace/adminAvail";
							var msg = 'Bank administrator added successfully.';
							// $.ajax({
							// 		url: url_name,
							// 		type: "POST",
							// 		data:{'email':ajaxData['email'],'mobile':ajaxData['mobile_no'],'bankId':ajaxData['bank_id']},
							// 		success: function(response){
							// 			//alert('Hi 33');	
							// 			//alert(response);		
							// 			var msg = 'Administrator already available.';														
							// 		}
							// 	}); 
							break;
						case 'Agency':
							ajaxData['change_status'] = 'add_agency';
							var msg = 'Agency added successfully.';
							break;
						case 'Agency Administrator':
							ajaxData['change_status'] = 'add_agency_administrator';
							var msg = 'Agency administrator added successfully.';
							break;
						case 'Make':
							ajaxData['change_status'] = 'add_make';
							var msg = 'Make added successfully.';
							break;
						case 'Platecode':
							ajaxData['change_status'] = 'add_platecode';
							var msg = 'Plate code added successfully.';
							break;	
					}
					//alert(msg);
					var url_name = base_url+$('#controller_name').val();
					$.ajax({
						type:'POST',
						data:ajaxData,
						url:url_name,
						success:function(response) {
							//alert('Hi22');
							//alert(response);
							$('#myModal').modal('hide');
						 	$( '.modal-backdrop' ).hide();
						 	$('.content-wrapper').html(response);
						  	$('.div-msg').html(msg);
						 	$('body').removeClass('modal-open');
						  /* Search functionality */
							searchDetails();
							/* date picker */
							dateDetails();
							updateConfig();
							/* view all details on clik */
							viewAllDetails();
							/* view claim by details on click */
							viewClaimByDetails();
							/* view user details on click */
							viewUserDetails();							
							setNiceScroll();
							$('#txtCurrentPage').keydown(function(event){
								if(event.which == 13){
									if(isNaN($(this).val())){
										alert("Please enter valid page number.");
									}else{
										if(parseInt($('#txtTotalPages').val()) < parseInt($(this).val())){
											alert("Enter valid page number.");
										}else{
											setPageNumber($(this).val());
										}
									}
								}
							});							
						  return false;
						}
					});
				});
			}
		}); 	
	}		
/**************************************************************************
 Purpose 		: Change status 
 Inputs  		: ids
 Return 		: none.
 Created By 	: Kundan Kumar
/**************************************************************************/
function searchBox(currentObj){	
	$('#searchBox').toggle();
	/* updated by Bhakti Start*/
	var url_name = base_url+$('#controller_name').val()+"/SearchColumns";
	var data = {};
	data['tableHTML'] = $(currentObj).parent().parent().parent().find('.table-bordered thead').html();
	$.ajax({
		url: url_name,
		type: "POST",
		data:data,
		success: function(response){	
		
			$('.modal-content').html(response);
			$('.modal-content').find('.table-bordered tbody').find('tr:first').remove();
			$('.modal-content').find('tr').show();
			setMultiSelectDropDOwn();
			updateConfig();
			searchDetails();
			$('.search_plate_source_emirates').keyup(function(e) {				
				var url_name = base_url+"Car_trace/SearchPlateCodeValue";
				var cityName = $(this).val();
				$.ajax({
						url: url_name,
						type: "POST",
						data:{'cityName':cityName},
						success: function(response){			
							$('.search_plate_code').html(response);																
						}
					}); 
			}); 
				
			$('.search_bank_name').change(function(e) {
				var url_name = base_url+"Chat_trace/SearchReceiverName";
				var bankId = $(this).val();
				$.ajax({
						url: url_name,
						type: "POST",
						data:{'bankId':bankId},
						success: function(response){	
							$('.search_receiver_name').html(response);
						}
					}); 
			});
			$('.search_sender_name').keyup(function(e) {
				var url_name = base_url+"Chat_trace/SearchSenderName";
				var nameData = $(this).val();
				$.ajax({
						url: url_name,
						type: "POST",
						data:{'nameData':nameData},
						success: function(response){	
							$('.search_sender_name').html(response);
						}
					}); 
			});
		}
	});			
}
/**************************************************************************
 Purpose 		: Inactive Bank 
 Inputs  		: id
 Return 		: none.
 Created By 	: Kundan Kumar
/**************************************************************************/
function inactiveData(dataId,mName){
	if (confirm('Are you sure want to inactivate ?')) {
		if(mName == '/Bank/'){
			var url_name = base_url+"Bank_trace/inactiveBank";
		}else if(mName == '/Administrator/'){
			var url_name = base_url+"Bank_administrative_user_trace/inactiveBankAdmin";
		}else if(mName == '/Agency/'){
			var url_name = base_url+"Agency_trace/inactiveAgency";	
		}else if(mName == '/Agency Administrator/'){
			var url_name = base_url+"Collection_agency_administrative_user_trace/inactiveAgencyAdmin";
		}else if(mName == '/Make/'){
			var url_name = base_url+"Make_trace/inactiveMake";
		}else if(mName == '/Platecode/'){
			var url_name = base_url+"Platecode_trace/inactivePlatecode";	
		}			
		$.ajax({			
			url: url_name,
			type: "POST",
			data:{'dataId':dataId},
			success: function(response){				
				location.reload();	
			}
		}); 
	} else {
		// Do nothing!
	}
}
/**************************************************************************
 Purpose 		: Download file 
 Inputs  		: ids
 Return 		: none.
 Created By 	: Kundan Kumar
/**************************************************************************/
function download_file( fileName){
	$.ajax({
			url: base_url+"Car_trace/download_file",
			type: "POST",
			data:{'fileName':fileName},
			success: function(response){					
				return false;			
			}
		}); 	
}
function setNiceScroll(){
	$(".data_load").mCustomScrollbar({
		axis:"yx",	
		theme:"dark",	
		//mouseWheel:false, 
		//scrollButtons:{enable:true},
		//advanced:{autoExpandHorizontalScroll:true},
		horizontalScroll: true,
		scrollbarPosition:"outside"
	});
	$(".tableHeaderFixedBox thead").css("display", "block");
	$(".tableHeaderFixedBox tbody").css("display", "block"); 
}
 

	/*$('#DataTable').DataTable( {
        "scrollY": 200,
        "scrollX": true
    });*/



function setMultiSelectDropDOwn(){
	var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
}